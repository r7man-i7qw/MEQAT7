import { store } from '../store.js';
import { h, clear, nf, toast } from '../dom.js';
import { loadAdhkar, onDataChange } from '../data.js';
import { runAdhkarDownload } from '../data-actions.js';
import { groupAdhkar } from '../adhkar-source.js';
import * as C from '../counter.js';

const SECTION_TITLES = [
  ['morningEvening', 'أذكار الصباح والمساء'],
  ['morning', 'أذكار الصباح'],
  ['evening', 'أذكار المساء'],
  ['sleep', 'أذكار النوم'],
  ['wake', 'أذكار الاستيقاظ'],
  ['afterPrayer', 'أذكار بعد الصلاة'],
];

export function initAdhkar(root) {
  let rec = null;
  let sections = null;
  let view = { type: 'list' }; // list | misc | cat
  let progress = C.normalizeProgress(store.getKV('adhkarProgress', null), C.dayKey());
  const body = h('div', {});
  root.append(body);

  const persist = () => store.setKV('adhkarProgress', progress);
  const fresh = () => {
    progress = C.normalizeProgress(progress, C.dayKey());
    return progress;
  };

  async function ensure() {
    rec = await loadAdhkar();
    sections = rec ? groupAdhkar(rec.data.categories) : null;
    render();
  }

  function renderMissing() {
    clear(body);
    const out = h('div', { class: 'banner', hidden: true });
    const btn = h('button', { class: 'btn' }, 'تنزيل الأذكار للاستخدام دون إنترنت');
    btn.addEventListener('click', async () => {
      btn.disabled = true;
      out.hidden = false;
      out.className = 'banner';
      out.textContent = 'جارٍ التنزيل والفحص…';
      const r = await runAdhkarDownload();
      btn.disabled = false;
      if (!r.ok) {
        out.className = 'banner warn';
        out.textContent = `${r.message}. يمكنك استيراد ملف أذكار JSON من الإعدادات.`;
      }
    });
    body.append(
      h('h1', { class: 'page-title' }, 'الأذكار'),
      h('section', { class: 'card center' },
        h('p', {}, 'بيانات الأذكار غير متوفرة على هذا الجهاز بعد.'),
        h('p', { class: 'sub' }, 'تُنزَّل الأذكار من مجموعة بيانات مفتوحة لحصن المسلم وتُحفظ على جهازك للعمل دون إنترنت. لا تُعدَّل ألفاظها.'),
        btn, out),
    );
  }

  function catCard(cat, onOpen) {
    const { done, total } = C.categoryProgress(fresh(), cat);
    return h('button', { class: 'card cat-card', onclick: onOpen },
      h('div', { class: 'cat-title' }, cat.title),
      h('div', { class: 'sub' }, `${nf(total)} ذكر • أنجزت ${nf(done)}`),
      h('div', { class: 'bar' }, h('i', { style: `width:${total ? (done / total) * 100 : 0}%` })));
  }

  function renderList() {
    clear(body);
    body.append(h('h1', { class: 'page-title' }, 'الأذكار'));
    for (const [key, title] of SECTION_TITLES) {
      for (const cat of sections[key]) {
        body.append(catCard({ ...cat, title: key === 'morningEvening' || sections[key].length === 1 ? title : cat.title }, () => openCat(cat)));
      }
    }
    if (sections.misc.length) body.append(h('button', { class: 'card cat-card', onclick: () => { view = { type: 'misc' }; render(); } }, h('div', { class: 'cat-title' }, 'أذكار متنوعة'), h('div', { class: 'sub' }, `${nf(sections.misc.length)} تصنيف`)));
    body.append(h('div', { class: 'foot-note' }, `المصدر: ${rec.data.source}. يبدأ العدّاد من الصفر كل يوم تلقائيًا. تُعرض الأذكار كما وردت في المصدر دون تعديل، وتصنيف «الصباح والمساء» كما ورد في المصدر مجموعة واحدة.`));
  }

  function renderMisc() {
    clear(body);
    body.append(h('div', { class: 'reader-bar' }, h('button', { class: 'btn ghost', onclick: () => { view = { type: 'list' }; render(); } }, '‹ الأذكار'), h('h2', { class: 'bar-title' }, 'أذكار متنوعة')));
    for (const cat of sections.misc) body.append(catCard(cat, () => openCat(cat, 'misc')));
  }

  function openCat(cat, from = 'list') {
    view = { type: 'cat', catId: cat.id, from, i: 0 };
    // jump to the first unfinished item so users can resume after closing the app
    const p = fresh();
    const firstOpen = cat.items.findIndex((it, i) => !C.isDone(p, C.itemKey(cat.id, i), it.count));
    view.i = firstOpen >= 0 ? firstOpen : 0;
    render();
  }

  function renderCat(keepScroll = false) {
    clear(body);
    const cat = rec.data.categories.find((c) => c.id === view.catId);
    if (!cat) {
      view = { type: 'list' };
      return render();
    }
    const i = view.i;
    const it = cat.items[i];
    const key = C.itemKey(cat.id, i);
    const fs = store.get().adhkarFontSize;
    const count = C.getCount(fresh(), key);
    const done = C.isDone(progress, key, it.count);
    const { done: nd, total } = C.categoryProgress(progress, cat);

    const counterBtn = h('button', { class: `counter ${done ? 'done' : ''}`, 'aria-label': 'اضغط لزيادة العدّاد' },
      h('span', { class: 'cnum' }, nf(count)),
      h('span', { class: 'ctarget' }, it.count ? `من ${nf(it.count)}` : 'عدد غير محدد'));
    counterBtn.addEventListener('click', () => {
      const before = C.getCount(progress, key);
      progress = C.tap(fresh(), key, it.count);
      if (C.getCount(progress, key) === before) return toast('اكتمل هذا الذكر');
      persist();
      if (store.get().vibrate && navigator.vibrate) navigator.vibrate(C.isDone(progress, key, it.count) ? [30, 40, 30] : 15);
      const nowDone = C.isDone(progress, key, it.count);
      if (nowDone && i < cat.items.length - 1) {
        // smooth advance to next dhikr
        setTimeout(() => { if (view.type === 'cat' && view.i === i) { view.i = i + 1; render(); } }, 450);
      }
      renderCat(true);
    });

    body.append(
      h('div', { class: 'reader-bar' },
        h('button', { class: 'btn ghost', onclick: () => { view = { type: view.from === 'misc' ? 'misc' : 'list' }; render(); } }, `‹ ${view.from === 'misc' ? 'المتنوعة' : 'الأذكار'}`),
        h('h2', { class: 'bar-title' }, cat.title),
        h('div', { class: 'font-ctl' },
          h('button', { class: 'btn ghost', 'aria-label': 'تصغير الخط', onclick: () => store.update({ adhkarFontSize: Math.max(18, store.get().adhkarFontSize - 2) }) }, 'أ−'),
          h('button', { class: 'btn ghost', 'aria-label': 'تكبير الخط', onclick: () => store.update({ adhkarFontSize: Math.min(44, store.get().adhkarFontSize + 2) }) }, 'أ+'))),
      h('div', { class: 'bar' }, h('i', { style: `width:${(nd / total) * 100}%` })),
      h('div', { class: 'sub center' }, `الذكر ${nf(i + 1)} من ${nf(cat.items.length)} • أنجزت ${nf(nd)} من ${nf(total)}`),
      h('section', { class: 'card dhikr' }, h('div', { class: 'dhikr-text', style: `font-size:${fs}px` }, it.text)),
      h('div', { class: 'row-center' }, counterBtn),
      h('div', { class: 'row-between' },
        h('button', { class: 'btn ghost', disabled: i === 0, onclick: () => { view.i = i - 1; render(); } }, '› السابق'),
        h('button', { class: 'btn ghost', onclick: () => { progress = C.resetItem(fresh(), key); persist(); renderCat(true); } }, 'إعادة العدّاد'),
        h('button', { class: 'btn ghost', disabled: i === cat.items.length - 1, onclick: () => { view.i = i + 1; render(); } }, 'التالي ‹')),
      h('div', { class: 'row-center' }, h('button', { class: 'btn ghost danger-text', onclick: () => { progress = C.resetCategory(fresh(), cat.id); persist(); view.i = 0; render(); } }, 'إعادة كل عدّادات هذا التصنيف')),
      h('div', { class: 'foot-note' }, `المصدر: ${rec.data.source}`),
    );
    if (!keepScroll) window.scrollTo(0, 0);
  }

  function render() {
    if (!rec) return renderMissing();
    if (view.type === 'cat') return renderCat();
    if (view.type === 'misc') return renderMisc();
    return renderList();
  }

  store.subscribe((s) => {
    const el = body.querySelector('.dhikr-text');
    if (el) el.style.fontSize = `${s.adhkarFontSize}px`;
  });
  onDataChange(() => ensure());
  ensure();

  return { onShow: () => (view.type === 'cat' ? null : render()), onHide() {} };
}
