import { store } from './store.js';
import { $ } from './dom.js';
import { initHome } from './views/home.js';
import { initQibla } from './views/qibla.js';
import { initQuran } from './views/quran.js';
import { initAdhkar } from './views/adhkar.js';
import { initSettings } from './views/settings.js';
import { initAdhan } from './adhan.js';

const TABS = ['home', 'qibla', 'quran', 'adhkar', 'settings'];
const views = {};
let active = null;

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  const dark = theme === 'dark' || (theme === 'system' && matchMedia('(prefers-color-scheme: dark)').matches);
  $('meta[name="theme-color"]')?.setAttribute('content', dark ? '#121410' : '#FAF9F6');
}

function go(tab) {
  if (!TABS.includes(tab)) tab = 'home';
  if (tab === active) return;
  if (active) {
    $(`#view-${active}`).classList.remove('active');
    views[active]?.onHide?.();
  }
  active = tab;
  const el = $(`#view-${tab}`);
  el.classList.add('active');
  document.querySelectorAll('#tabs a').forEach((a) => {
    const on = a.dataset.tab === tab;
    a.classList.toggle('on', on);
    if (on) a.setAttribute('aria-current', 'page');
    else a.removeAttribute('aria-current');
  });
  views[tab]?.onShow?.();
  window.scrollTo(0, 0);
}

function boot() {
  applyTheme(store.get().theme);
  store.subscribe((s) => applyTheme(s.theme));
  matchMedia('(prefers-color-scheme: dark)').addEventListener?.('change', () => applyTheme(store.get().theme));

  initAdhan(); // must be created before Settings so its settings subscription runs first
  views.home = initHome($('#view-home'));
  views.qibla = initQibla($('#view-qibla'));
  views.quran = initQuran($('#view-quran'));
  views.adhkar = initAdhkar($('#view-adhkar'));
  views.settings = initSettings($('#view-settings'));

  window.addEventListener('hashchange', () => go(location.hash.slice(1)));
  go(location.hash.slice(1) || 'home');

  setTimeout(() => $('#splash')?.classList.add('hide'), 900);
  setTimeout(() => $('#splash')?.remove(), 1500);

  if ('serviceWorker' in navigator && location.protocol !== 'file:') {
    navigator.serviceWorker.register('sw.js').catch(() => {
      /* offline shell is optional; app still works online */
    });
  }
}

boot();
