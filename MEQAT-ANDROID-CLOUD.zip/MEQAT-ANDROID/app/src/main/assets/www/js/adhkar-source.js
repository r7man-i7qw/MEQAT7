// Adhkar data: download/import, parse, validate and group. No adhkar text is stored in this file.
// Source default: open JSON dataset of Hisn al-Muslim (rn0x/Adhkar-json). Content is never edited by the app.

export const ADHKAR_SOURCE = {
  label: 'مجموعة بيانات حصن المسلم المفتوحة (rn0x/Adhkar-json)',
  url: 'https://raw.githubusercontent.com/rn0x/Adhkar-json/main/adhkar.json',
};

const pick = (o, keys) => {
  for (const k of keys) if (o && o[k] != null) return o[k];
  return undefined;
};

/** Accepts either an array of categories or { categories: [...] }. */
export function parseAdhkar(json) {
  const cats = Array.isArray(json) ? json : json?.categories;
  if (!Array.isArray(cats)) throw new Error('صيغة غير معروفة');
  const out = [];
  cats.forEach((c, ci) => {
    const title = String(pick(c, ['category', 'title', 'name']) ?? '').trim();
    const rawItems = pick(c, ['array', 'items', 'adhkar']);
    if (!title || !Array.isArray(rawItems)) return;
    const items = [];
    for (const it of rawItems) {
      const text = String(pick(it, ['text', 'zekr', 'content']) ?? '').trim();
      if (!text) continue;
      const n = Number(pick(it, ['count', 'repeat']));
      items.push({ text, count: Number.isInteger(n) && n >= 1 ? n : null });
    }
    if (items.length) out.push({ id: `c${ci}`, title, items });
  });
  return out;
}

export function validateAdhkar(cats) {
  const errors = [];
  if (!Array.isArray(cats) || cats.length < 5) errors.push('عدد التصنيفات أقل من المتوقع');
  for (const c of cats || []) {
    for (const it of c.items) {
      if (!/[؀-ۿ]/.test(it.text) || it.text.includes('�')) {
        errors.push(`نص غير صالح في «${c.title}»`);
        break;
      }
    }
  }
  return { ok: errors.length === 0, errors: errors.slice(0, 6) };
}

export async function downloadAdhkar(signal) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 30000);
  signal?.addEventListener('abort', () => ctl.abort(), { once: true });
  try {
    const res = await fetch(ADHKAR_SOURCE.url, { signal: ctl.signal, credentials: 'omit', referrerPolicy: 'no-referrer' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const cats = parseAdhkar(await res.json());
    const v = validateAdhkar(cats);
    if (!v.ok) throw new Error(`فشل فحص السلامة: ${v.errors.join('؛ ')}`);
    return { source: ADHKAR_SOURCE.label, sourceUrl: ADHKAR_SOURCE.url, fetchedAt: Date.now(), categories: cats };
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Groups source categories into the app's sections by their Arabic titles.
 * Sections that the source does not contain are simply not produced (no invented content).
 */
export function groupAdhkar(cats) {
  const sections = {
    morningEvening: [],
    morning: [],
    evening: [],
    sleep: [],
    wake: [],
    afterPrayer: [],
    misc: [],
  };
  for (const c of cats) {
    const t = c.title;
    if (t.includes('الصباح') && t.includes('المساء')) sections.morningEvening.push(c);
    else if (t.includes('الصباح')) sections.morning.push(c);
    else if (t.includes('المساء')) sections.evening.push(c);
    else if (t.includes('الاستيقاظ')) sections.wake.push(c);
    else if (t.startsWith('أذكار النوم') || t === 'النوم') sections.sleep.push(c);
    else if (t.includes('بعد السلام من الصلاة') || t.includes('بعد الصلاة')) sections.afterPrayer.push(c);
    else sections.misc.push(c);
  }
  return sections;
}
