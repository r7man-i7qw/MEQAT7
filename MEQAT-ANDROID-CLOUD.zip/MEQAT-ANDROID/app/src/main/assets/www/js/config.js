// Central, editable app configuration. Edit this file to change contact details or the version.

export const APP = {
  name: 'مِيقات | MEQAT',
  tagline: 'رفيقك إلى الصلاة',
  version: '1.0.0',
  developer: 'عبدالرحمن أحمد',
  instagram: { handle: 'r7man.i', url: 'https://instagram.com/r7man.i' },
};

// WhatsApp contact. The number is NEVER shown in the UI; it is only used to open wa.me.
// Put the number in international format with digits only (e.g. "201xxxxxxxxx").
// While it is empty the WhatsApp button is hidden (no dead buttons).
export const CONTACT = {
  whatsappNumber: '',
  whatsappMessage: 'السلام عليكم، بخصوص تطبيق ميقات',
};

// Alert sounds. Add licensed audio files under /sounds and list them in sounds/manifest.json.
export const SOUNDS_MANIFEST_URL = 'sounds/manifest.json';
export const BUILTIN_CHIME = { id: 'chime', name: 'تنبيه قصير (نغمة مدمجة)', kind: 'short' };

export const PRAYER_NAMES = {
  fajr: 'الفجر',
  sunrise: 'الشروق',
  dhuhr: 'الظهر',
  asr: 'العصر',
  maghrib: 'المغرب',
  isha: 'العشاء',
};

export const CITIES = [
  { id: 'bir-al-abd', name: 'بئر العبد، شمال سيناء', lat: 31.02, lng: 33.0, tz: 'Africa/Cairo' },
  { id: 'cairo', name: 'القاهرة', lat: 30.0444, lng: 31.2357, tz: 'Africa/Cairo' },
  { id: 'giza', name: 'الجيزة', lat: 30.0131, lng: 31.2089, tz: 'Africa/Cairo' },
  { id: 'alexandria', name: 'الإسكندرية', lat: 31.2001, lng: 29.9187, tz: 'Africa/Cairo' },
  { id: 'port-said', name: 'بورسعيد', lat: 31.2653, lng: 32.3019, tz: 'Africa/Cairo' },
  { id: 'suez', name: 'السويس', lat: 29.9668, lng: 32.5498, tz: 'Africa/Cairo' },
  { id: 'ismailia', name: 'الإسماعيلية', lat: 30.5965, lng: 32.2715, tz: 'Africa/Cairo' },
  { id: 'arish', name: 'العريش', lat: 31.1316, lng: 33.7984, tz: 'Africa/Cairo' },
  { id: 'sharm', name: 'شرم الشيخ', lat: 27.9158, lng: 34.33, tz: 'Africa/Cairo' },
  { id: 'zagazig', name: 'الزقازيق', lat: 30.5877, lng: 31.502, tz: 'Africa/Cairo' },
  { id: 'damietta', name: 'دمياط', lat: 31.4165, lng: 31.8133, tz: 'Africa/Cairo' },
  { id: 'mansoura', name: 'المنصورة', lat: 31.0409, lng: 31.3785, tz: 'Africa/Cairo' },
  { id: 'tanta', name: 'طنطا', lat: 30.7865, lng: 31.0004, tz: 'Africa/Cairo' },
  { id: 'fayoum', name: 'الفيوم', lat: 29.3084, lng: 30.8428, tz: 'Africa/Cairo' },
  { id: 'beni-suef', name: 'بني سويف', lat: 29.0661, lng: 31.0994, tz: 'Africa/Cairo' },
  { id: 'minya', name: 'المنيا', lat: 28.1099, lng: 30.7503, tz: 'Africa/Cairo' },
  { id: 'asyut', name: 'أسيوط', lat: 27.1809, lng: 31.1837, tz: 'Africa/Cairo' },
  { id: 'sohag', name: 'سوهاج', lat: 26.5569, lng: 31.6948, tz: 'Africa/Cairo' },
  { id: 'qena', name: 'قنا', lat: 26.1551, lng: 32.716, tz: 'Africa/Cairo' },
  { id: 'luxor', name: 'الأقصر', lat: 25.6872, lng: 32.6396, tz: 'Africa/Cairo' },
  { id: 'aswan', name: 'أسوان', lat: 24.0889, lng: 32.8998, tz: 'Africa/Cairo' },
  { id: 'hurghada', name: 'الغردقة', lat: 27.2579, lng: 33.8116, tz: 'Africa/Cairo' },
  { id: 'makkah', name: 'مكة المكرمة', lat: 21.3891, lng: 39.8579, tz: 'Asia/Riyadh' },
  { id: 'madinah', name: 'المدينة المنورة', lat: 24.4686, lng: 39.6142, tz: 'Asia/Riyadh' },
  { id: 'riyadh', name: 'الرياض', lat: 24.7136, lng: 46.6753, tz: 'Asia/Riyadh' },
  { id: 'dubai', name: 'دبي', lat: 25.2048, lng: 55.2708, tz: 'Asia/Dubai' },
  { id: 'amman', name: 'عمّان', lat: 31.9454, lng: 35.9284, tz: 'Asia/Amman' },
];
