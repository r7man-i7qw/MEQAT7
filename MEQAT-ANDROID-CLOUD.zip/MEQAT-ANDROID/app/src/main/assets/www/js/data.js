// Offline datasets (Quran, Adhkar) in IndexedDB + status helpers.
import { idbGet, idbPut, idbDel } from './idb.js';
import { validateQuran, sha256Hex, quranFingerprintInput } from './quran-validate.js';
import { validateAdhkar } from './adhkar-source.js';

const Q = 'quran.v1';
const A = 'adhkar.v1';

let quranCache = null;
let adhkarCache = null;

export async function loadQuran() {
  if (quranCache) return quranCache;
  try {
    const rec = await idbGet(Q);
    if (rec?.data && validateQuran(rec.data).ok) quranCache = rec;
  } catch {
    /* IndexedDB unavailable -> treated as "not downloaded" */
  }
  return quranCache;
}

export async function saveQuran(data) {
  const v = validateQuran(data);
  if (!v.ok) throw new Error(`رفض الحفظ: ${v.errors.join('؛ ')}`);
  const hash = await sha256Hex(quranFingerprintInput(data));
  const rec = { data, hash, savedAt: Date.now() };
  await idbPut(Q, rec);
  quranCache = rec;
  return rec;
}

export async function deleteQuran() {
  quranCache = null;
  await idbDel(Q);
}

export async function loadAdhkar() {
  if (adhkarCache) return adhkarCache;
  try {
    const rec = await idbGet(A);
    if (rec?.data?.categories && validateAdhkar(rec.data.categories).ok) adhkarCache = rec;
  } catch {
    /* ignore */
  }
  return adhkarCache;
}

export async function saveAdhkar(data) {
  const v = validateAdhkar(data.categories);
  if (!v.ok) throw new Error(`رفض الحفظ: ${v.errors.join('؛ ')}`);
  const rec = { data, savedAt: Date.now() };
  await idbPut(A, rec);
  adhkarCache = rec;
  return rec;
}

export async function deleteAdhkar() {
  adhkarCache = null;
  await idbDel(A);
}

const listeners = new Set();
export const onDataChange = (f) => {
  listeners.add(f);
  return () => listeners.delete(f);
};
export const notifyDataChange = () => listeners.forEach((f) => f());

export function fmtDateTime(ms) {
  return new Intl.DateTimeFormat('ar-EG', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(ms));
}
