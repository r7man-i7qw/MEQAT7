// Quran data sources. The app never contains Quran text; it downloads it from an open source,
// validates it structurally (114 surahs / 6236 ayat / per-surah counts) and only then stores it.

import { validateQuran } from './quran-validate.js';

const TIMEOUT_MS = 60000;

async function getJSON(url, signal) {
  if (!url.startsWith('https://')) throw new Error('HTTPS only');
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), TIMEOUT_MS);
  signal?.addEventListener('abort', () => ctl.abort(), { once: true });
  try {
    const res = await fetch(url, { signal: ctl.signal, credentials: 'omit', referrerPolicy: 'no-referrer' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

// ---- Parsers (also used for user-imported JSON files) ----

/** AlQuran Cloud format: { data: { surahs: [{ number, name, revelationType, ayahs: [{ text, page, numberInSurah }] }] } } */
export function parseAlQuranCloud(json) {
  const surahs = json?.data?.surahs;
  if (!Array.isArray(surahs)) throw new Error('صيغة غير معروفة');
  return surahs.map((s) => {
    s.ayahs.forEach((a, i) => {
      if (a.numberInSurah !== undefined && a.numberInSurah !== i + 1) throw new Error('ترتيب الآيات غير صحيح');
    });
    return {
      n: s.number,
      name: s.name,
      type: s.revelationType === 'Meccan' ? 'makki' : s.revelationType === 'Medinan' ? 'madani' : null,
      ayahs: s.ayahs.map((a) => a.text),
      pages: s.ayahs.every((a) => Number.isInteger(a.page)) ? s.ayahs.map((a) => a.page) : null,
    };
  });
}

/** Already-normalized format produced by this app. */
export function parseNormalized(json) {
  if (!Array.isArray(json?.surahs)) throw new Error('صيغة غير معروفة');
  return json.surahs.map((s) => ({ n: s.n, name: s.name, type: s.type ?? null, ayahs: s.ayahs, pages: s.pages ?? null }));
}

export function parseAnyQuranJSON(json) {
  if (json?.data?.surahs) return parseAlQuranCloud(json);
  if (json?.surahs?.[0]?.ayahs && typeof json.surahs[0].n === 'number') return parseNormalized(json);
  throw new Error('صيغة الملف غير مدعومة');
}

// ---- Remote sources ----

export const QURAN_SOURCES = [
  {
    id: 'alquran-cloud',
    label: 'AlQuran Cloud API — النص العثماني (quran-uthmani)',
    url: 'https://api.alquran.cloud/v1/quran/quran-uthmani',
    async fetch(_onProgress, signal) {
      return parseAlQuranCloud(await getJSON(this.url, signal));
    },
  },
  {
    id: 'quran-com',
    label: 'Quran.com API v4 — النص العثماني (text_uthmani)',
    url: 'https://api.quran.com/api/v4/quran/verses/uthmani',
    async fetch(onProgress, signal) {
      const chapters = (await getJSON('https://api.quran.com/api/v4/chapters?language=ar', signal)).chapters;
      if (!Array.isArray(chapters) || chapters.length !== 114) throw new Error('قائمة السور غير مكتملة');
      const out = new Array(114);
      let done = 0;
      const queue = chapters.map((c, i) => ({ c, i }));
      const worker = async () => {
        while (queue.length) {
          const { c, i } = queue.shift();
          const j = await getJSON(`${this.url}?chapter_number=${c.id}`, signal);
          out[i] = {
            n: c.id,
            name: c.name_arabic,
            type: c.revelation_place === 'makkah' ? 'makki' : c.revelation_place === 'madinah' ? 'madani' : null,
            ayahs: j.verses.map((v) => v.text_uthmani),
            pages: null,
          };
          onProgress?.(++done / 114);
        }
      };
      await Promise.all([worker(), worker(), worker(), worker()]);
      return out;
    },
  },
];

/**
 * Tries each source in order. A source is accepted only if the result passes validation.
 * @returns {Promise<{data: object}>} throws Error with an Arabic message listing failures
 */
export async function downloadQuran({ onProgress, signal } = {}) {
  const failures = [];
  for (const src of QURAN_SOURCES) {
    try {
      onProgress?.(0, src.label);
      const surahs = await src.fetch(onProgress, signal);
      const data = { source: src.label, sourceUrl: src.url, fetchedAt: Date.now(), surahs };
      const v = validateQuran(data);
      if (!v.ok) throw new Error(`فشل فحص السلامة: ${v.errors.join('؛ ')}`);
      return { data };
    } catch (e) {
      if (e?.name === 'AbortError' && signal?.aborted) throw e;
      failures.push(`${src.label}: ${e?.message || e}`);
    }
  }
  const err = new Error('تعذّر تنزيل بيانات القرآن من أي مصدر.');
  err.details = failures;
  throw err;
}
