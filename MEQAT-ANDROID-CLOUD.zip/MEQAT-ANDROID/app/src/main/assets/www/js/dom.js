// Tiny DOM helpers. Never uses innerHTML with data: text is always set via text nodes.

export const $ = (sel, root = document) => root.querySelector(sel);

export function h(tag, attrs = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
    else if (k === 'value') el.value = v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const c of kids.flat(Infinity)) {
    if (c == null || c === false) continue;
    el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
  return el;
}

export const clear = (el) => el.replaceChildren();

export const nf = (n) => Number(n).toLocaleString('ar-EG');

let toastTimer;
export function toast(msg, ms = 3200) {
  const t = $('#toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), ms);
}

/** Confirm dialog using <dialog>. Resolves true/false. */
export function confirmDialog(message, okLabel = 'تأكيد', danger = false) {
  return new Promise((resolve) => {
    const dlg = h('dialog', { class: 'dlg', 'aria-label': 'تأكيد' });
    const done = (v) => {
      dlg.close();
      dlg.remove();
      resolve(v);
    };
    dlg.append(
      h('p', {}, message),
      h('div', { class: 'row-end' }, h('button', { class: 'btn ghost', onclick: () => done(false) }, 'إلغاء'), h('button', { class: `btn ${danger ? 'danger' : ''}`, onclick: () => done(true) }, okLabel)),
    );
    dlg.addEventListener('cancel', (e) => {
      e.preventDefault();
      done(false);
    });
    document.body.append(dlg);
    dlg.showModal();
  });
}

export function logoSVG(size = 48, id = 'lg') {
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('viewBox', '0 0 100 100');
  svg.setAttribute('width', size);
  svg.setAttribute('height', size);
  svg.setAttribute('aria-hidden', 'true');
  svg.innerHTML = `<defs><mask id="${id}"><rect width="100" height="100" fill="#fff"/><circle cx="61" cy="42" r="31" fill="#000"/></mask></defs><circle cx="46" cy="52" r="35" fill="currentColor" mask="url(#${id})"/>`;
  return svg;
}

export function debounce(fn, ms) {
  let t;
  return (...a) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...a), ms);
  };
}
