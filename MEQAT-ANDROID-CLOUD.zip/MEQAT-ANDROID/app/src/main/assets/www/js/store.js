// Settings + small key/value persistence. Storage is injected so it can be tested.

export const DEFAULT_ALERT = { alert: false, adhan: false, sound: 'chime', mode: 'short', pre: 0 };

export const DEFAULTS = {
  theme: 'system', // 'system' | 'light' | 'dark'
  timeFormat: '12', // '12' | '24'
  method: 'egypt',
  asr: 'standard', // 'standard' | 'hanafi'
  adjust: { fajr: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 },
  declination: 0, // magnetic declination correction in degrees (east positive)
  vibrate: true,
  quranFontSize: 30,
  adhkarFontSize: 26,
  volume: 1,
  location: { name: 'بئر العبد، شمال سيناء', lat: 31.02, lng: 33.0, tz: 'Africa/Cairo', source: 'default' },
  alerts: {
    fajr: { ...DEFAULT_ALERT },
    dhuhr: { ...DEFAULT_ALERT },
    asr: { ...DEFAULT_ALERT },
    maghrib: { ...DEFAULT_ALERT },
    isha: { ...DEFAULT_ALERT },
  },
};

export function deepMerge(base, over) {
  if (over === undefined) return structuredClone(base);
  if (base === null || typeof base !== 'object' || Array.isArray(base)) return over;
  if (over === null || typeof over !== 'object' || Array.isArray(over)) return over;
  const out = {};
  for (const k of Object.keys(base)) out[k] = deepMerge(base[k], over[k]);
  for (const k of Object.keys(over)) if (!(k in base)) out[k] = over[k];
  return out;
}

export function createStore(storage, key = 'meqat.settings.v1') {
  let s;
  try {
    const raw = storage.getItem(key);
    s = deepMerge(DEFAULTS, raw ? JSON.parse(raw) : undefined);
  } catch {
    s = structuredClone(DEFAULTS);
  }
  const subs = new Set();
  const persist = () => {
    try {
      storage.setItem(key, JSON.stringify(s));
      return true;
    } catch {
      return false;
    }
  };
  const kvKey = (k) => `meqat.kv.${k}`;
  return {
    get: () => s,
    update(patch) {
      s = deepMerge(s, patch);
      persist();
      subs.forEach((f) => f(s));
    },
    subscribe(f) {
      subs.add(f);
      return () => subs.delete(f);
    },
    getKV(k, fallback) {
      try {
        const raw = storage.getItem(kvKey(k));
        return raw == null ? fallback : JSON.parse(raw);
      } catch {
        return fallback;
      }
    },
    setKV(k, v) {
      try {
        storage.setItem(kvKey(k), JSON.stringify(v));
        return true;
      } catch {
        return false;
      }
    },
    delKV(k) {
      try {
        storage.removeItem(kvKey(k));
      } catch {
        /* ignore */
      }
    },
    /** Wipes settings and every kv entry (only called after explicit user confirmation). */
    clearAll() {
      try {
        const keys = [];
        for (let i = 0; i < storage.length; i++) keys.push(storage.key(i));
        keys.filter((k) => k === key || k.startsWith('meqat.kv.')).forEach((k) => storage.removeItem(k));
      } catch {
        /* ignore */
      }
      s = structuredClone(DEFAULTS);
      subs.forEach((f) => f(s));
    },
  };
}

function safeLocalStorage() {
  try {
    const t = '__meqat_test__';
    localStorage.setItem(t, '1');
    localStorage.removeItem(t);
    return localStorage;
  } catch {
    const m = new Map();
    return {
      getItem: (k) => (m.has(k) ? m.get(k) : null),
      setItem: (k, v) => m.set(k, String(v)),
      removeItem: (k) => m.delete(k),
      key: (i) => [...m.keys()][i] ?? null,
      get length() {
        return m.size;
      },
    };
  }
}

export const store = typeof localStorage !== 'undefined' || typeof window !== 'undefined' ? createStore(safeLocalStorage()) : null;
