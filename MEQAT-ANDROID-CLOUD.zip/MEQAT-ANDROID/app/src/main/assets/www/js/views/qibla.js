import { store } from '../store.js';
import { h, clear, nf, toast } from '../dom.js';
import { qiblaBearing, distanceKm, angleDiff, smoothHeading, headingJitter, toTrueHeading } from '../qibla.js';

const NS = 'http://www.w3.org/2000/svg';
const S = (tag, attrs = {}, ...kids) => {
  const e = document.createElementNS(NS, tag);
  for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v);
  kids.forEach((k) => e.append(k));
  return e;
};

export function initQibla(root) {
  let running = false;
  let wantRunning = false; // user pressed start; resume when the tab becomes visible again
  let heading = null;
  let samples = [];
  let raf = 0;
  let lastEvent = 0;
  let watchdog = null;
  let usedAbsolute = false;

  const info = h('div', { class: 'qibla-info' });
  const status = h('div', { class: 'banner', hidden: true });
  const diffEl = h('div', { class: 'qibla-diff' });
  const startBtn = h('button', { class: 'btn', onclick: toggle }, 'تشغيل البوصلة');

  const dial = S('g', { id: 'dial' });
  const svg = S('svg', { viewBox: '-110 -110 220 220', class: 'compass', role: 'img', 'aria-label': 'بوصلة اتجاه القبلة' });
  const ring = S('circle', { r: 100, class: 'ring' });
  dial.append(ring);
  for (let a = 0; a < 360; a += 30) {
    dial.append(S('line', { x1: 0, y1: -100, x2: 0, y2: a % 90 === 0 ? -86 : -92, class: 'tick', transform: `rotate(${a})` }));
  }
  const cardinals = [['شمال', 0], ['شرق', 90], ['جنوب', 180], ['غرب', 270]];
  for (const [t, a] of cardinals) {
    // rotate to the cardinal position, then counter-rotate so the word stays upright when the dial is north-up
    const tx = S('text', { x: 0, y: 0, class: 'card', transform: `rotate(${a}) translate(0,-68) rotate(${-a})`, 'text-anchor': 'middle', 'dominant-baseline': 'middle' });
    tx.textContent = t;
    dial.append(tx);
  }
  const marker = S('g', { id: 'qmark' }, S('path', { d: 'M0,-104 L9,-82 L-9,-82 Z', class: 'qpoint' }), S('circle', { cx: 0, cy: -64, r: 7, class: 'qdot' }));
  dial.append(marker);
  svg.append(dial, S('path', { d: 'M0,-52 L7,0 L-7,0 Z', class: 'needle' }), S('circle', { r: 5, class: 'hub' }));

  root.append(
    h('h1', { class: 'page-title' }, 'القبلة'),
    info,
    h('section', { class: 'card compass-card' }, svg, diffEl),
    status,
    h('div', { class: 'row-center' }, startBtn),
    h('details', { class: 'card tips' },
      h('summary', {}, 'معايرة البوصلة وملاحظات الدقة'),
      h('ul', {},
        h('li', {}, 'حرّك الهاتف في الهواء بحركة رقم ٨ عدة مرات لمعايرة المستشعر.'),
        h('li', {}, 'ابتعد عن المعادن والمغناطيس وأجهزة الشحن اللاسلكي والسماعات الكبيرة.'),
        h('li', {}, 'أمسك الهاتف أفقيًا ومستويًا أثناء القراءة.'),
        h('li', {}, 'الاتجاه المحسوب من موقعك دقيق، أما قراءة البوصلة فتتأثر بالمستشعر والانحراف المغناطيسي؛ يمكنك ضبط الانحراف المغناطيسي من الإعدادات.'),
      )),
  );

  function bearing() {
    const { lat, lng } = store.get().location;
    return qiblaBearing(lat, lng);
  }

  function renderStatic() {
    const s = store.get();
    const b = bearing();
    clear(info);
    info.append(
      h('div', { class: 'big-deg' }, `${nf(Math.round(b))}°`),
      h('div', { class: 'sub' }, `اتجاه القبلة من الشمال الحقيقي في ${s.location.name}`),
      h('div', { class: 'sub' }, `المسافة إلى الكعبة المشرفة ≈ ${nf(Math.round(distanceKm(s.location.lat, s.location.lng)))} كم`),
    );
    // Without live heading the dial stays north-up and only shows the computed direction.
    if (heading == null) {
      dial.setAttribute('transform', 'rotate(0)');
      marker.setAttribute('transform', `rotate(${b})`);
      diffEl.classList.add('hint');
      diffEl.textContent = running ? 'بانتظار قراءات المستشعر…' : 'لا تظهر بوصلة حية حتى تشغّل المستشعر. السهم على المحيط يشير إلى اتجاه القبلة بالنسبة للشمال (ش).';
    }
  }

  function setStatus(text, warn = true) {
    status.hidden = !text;
    status.className = `banner ${warn ? 'warn' : ''}`;
    status.textContent = text || '';
  }

  function handle(e) {
    let h0 = null;
    if (typeof e.webkitCompassHeading === 'number') {
      h0 = e.webkitCompassHeading; // iOS: magnetic heading, clockwise from north
      usedAbsolute = true;
    } else if (e.absolute === true && typeof e.alpha === 'number') {
      h0 = (360 - e.alpha) % 360;
      usedAbsolute = true;
    }
    if (h0 == null) return;
    lastEvent = Date.now();
    const trueH = toTrueHeading(h0, Number(store.get().declination) || 0);
    heading = smoothHeading(heading, trueH, 0.18);
    samples.push(trueH);
    if (samples.length > 25) samples.shift();
    if (!raf) raf = requestAnimationFrame(draw);
  }

  function draw() {
    raf = 0;
    if (heading == null) return;
    const b = bearing();
    dial.setAttribute('transform', `rotate(${-heading})`);
    marker.setAttribute('transform', `rotate(${b})`);
    const d = angleDiff(b, heading);
    diffEl.classList.remove('hint');
    const aligned = Math.abs(d) <= 3;
    diffEl.textContent = aligned ? 'أنت تواجه القبلة ✓' : `${d > 0 ? 'أدر الهاتف يمينًا' : 'أدر الهاتف يسارًا'} ${nf(Math.round(Math.abs(d)))}°`;
    diffEl.classList.toggle('ok', aligned);
    ring.classList.toggle('ok', aligned);
    if (headingJitter(samples) > 12) setStatus('القراءة غير مستقرة. عاير البوصلة بحركة رقم ٨ وابتعد عن المعادن.');
    else setStatus('');
  }

  async function start() {
    if (running) return;
    if (typeof window.DeviceOrientationEvent === 'undefined') {
      setStatus('هذا الجهاز أو المتصفح لا يوفّر مستشعر اتجاه، لذلك لا تتوفر بوصلة حية. اتجاه القبلة المحسوب من موقعك معروض أعلاه فقط.');
      return;
    }
    try {
      if (typeof DeviceOrientationEvent.requestPermission === 'function') {
        const r = await DeviceOrientationEvent.requestPermission();
        if (r !== 'granted') {
          setStatus('تم رفض إذن مستشعر الاتجاه. اسمح به من إعدادات المتصفح لتشغيل البوصلة الحية.');
          return;
        }
      }
    } catch {
      setStatus('تعذّر طلب إذن مستشعر الاتجاه.');
      return;
    }
    running = true;
    wantRunning = true;
    usedAbsolute = false;
    lastEvent = 0;
    window.addEventListener('deviceorientationabsolute', handle, true);
    window.addEventListener('deviceorientation', handle, true);
    startBtn.textContent = 'إيقاف البوصلة';
    renderStatic();
    clearTimeout(watchdog);
    watchdog = setTimeout(() => {
      if (running && !lastEvent) {
        stop(true);
        setStatus(usedAbsolute ? '' : 'لم تصل قراءات اتجاه حقيقية من هذا الجهاز (لا يوجد مستشعر بوصلة مناسب أو المتصفح لا يدعمه). اتجاه القبلة المحسوب أعلاه صحيح لكن لا يمكن عرض بوصلة حية.');
      }
    }, 3000);
  }

  function stop(keepWanted = false) {
    window.removeEventListener('deviceorientationabsolute', handle, true);
    window.removeEventListener('deviceorientation', handle, true);
    cancelAnimationFrame(raf);
    raf = 0;
    clearTimeout(watchdog);
    running = false;
    if (!keepWanted) wantRunning = false;
    heading = null;
    samples = [];
    startBtn.textContent = 'تشغيل البوصلة';
    renderStatic();
  }

  function toggle() {
    if (running) stop();
    else start();
  }

  store.subscribe(() => renderStatic());
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden' && running) stop(true); // save battery
    else if (document.visibilityState === 'visible' && wantRunning && root.classList.contains('active')) start();
  });
  renderStatic();
  void toast;

  return {
    onShow() {
      renderStatic();
      if (wantRunning) start();
    },
    onHide() {
      if (running) stop(true); // sensors are never left on while the screen is not visible
    },
  };
}
