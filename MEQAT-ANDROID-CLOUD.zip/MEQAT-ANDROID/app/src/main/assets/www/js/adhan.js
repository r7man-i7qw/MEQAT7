// In-page alerts: timers + Notification API + audio.
// LIMITATION (by design of the web platform): a website cannot guarantee sound or notifications while the
// browser/PWA is closed or the device is asleep. This module only works while the page is open or alive in background.
import { store } from './store.js';
import { PRAYERS } from './prayer.js';
import { buildEvents, isStale } from './adhan-core.js';
import { computeDay, localYMD, addDays, fmtTime } from './prayer-service.js';
import { PRAYER_NAMES, SOUNDS_MANIFEST_URL, BUILTIN_CHIME } from './config.js';
import { toast } from './dom.js';

let timer = null;
let next = null; // next scheduled event (for the status line)
let listeners = new Set();
let audioEl = null;
let ctx = null;
let customSounds = [];

export const onScheduleChange = (f) => {
  listeners.add(f);
  return () => listeners.delete(f);
};
const emit = () => listeners.forEach((f) => f(next));

export function notificationState() {
  if (typeof Notification === 'undefined') return 'unsupported';
  return Notification.permission; // 'default' | 'granted' | 'denied'
}

export async function requestNotifications() {
  if (typeof Notification === 'undefined') return 'unsupported';
  try {
    return await Notification.requestPermission();
  } catch {
    return Notification.permission;
  }
}

export async function loadSounds() {
  try {
    const res = await fetch(SOUNDS_MANIFEST_URL, { cache: 'no-cache' });
    if (!res.ok) throw new Error('no manifest');
    const j = await res.json();
    customSounds = (Array.isArray(j.sounds) ? j.sounds : []).filter((s) => s && s.id && s.name && s.file && (s.kind === 'adhan' || s.kind === 'short'));
  } catch {
    customSounds = [];
  }
  return customSounds;
}

export const availableSounds = () => [BUILTIN_CHIME, ...customSounds];
export const hasAdhanFiles = () => customSounds.some((s) => s.kind === 'adhan');

function chime(volume = 1) {
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) throw new Error('no audio');
  ctx = ctx || new AC();
  if (ctx.state === 'suspended') ctx.resume();
  const now = ctx.currentTime;
  [[659.25, 0], [880, 0.35], [1318.5, 0.7]].forEach(([f, t]) => {
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = 'sine';
    o.frequency.value = f;
    g.gain.setValueAtTime(0.0001, now + t);
    g.gain.exponentialRampToValueAtTime(0.3 * volume, now + t + 0.05);
    g.gain.exponentialRampToValueAtTime(0.0001, now + t + 1.2);
    o.connect(g).connect(ctx.destination);
    o.start(now + t);
    o.stop(now + t + 1.3);
  });
}

export function stopSound() {
  if (audioEl) {
    audioEl.pause();
    audioEl = null;
  }
}

/** Plays a sound. Returns {ok:false,message} instead of throwing (autoplay policies may block audio). */
export async function playSound(soundId, volume = store.get().volume) {
  stopSound();
  try {
    if (!soundId || soundId === BUILTIN_CHIME.id) {
      chime(volume);
      return { ok: true };
    }
    const s = customSounds.find((x) => x.id === soundId);
    if (!s) {
      chime(volume);
      return { ok: true, fallback: true };
    }
    audioEl = new Audio(s.file);
    audioEl.volume = Math.min(1, Math.max(0, volume));
    await audioEl.play();
    return { ok: true };
  } catch {
    return { ok: false, message: 'منع المتصفح تشغيل الصوت. اضغط في أي مكان بالصفحة ثم حاول مجددًا.' };
  }
}

async function notify(title, body, tag) {
  if (notificationState() !== 'granted') return false;
  try {
    const reg = await navigator.serviceWorker?.getRegistration();
    const opts = { body, tag, icon: 'icons/icon-192.png', badge: 'icons/icon-192.png', dir: 'rtl', lang: 'ar', renotify: false };
    if (reg) await reg.showNotification(title, opts);
    else new Notification(title, opts);
    return true;
  } catch {
    return false;
  }
}

async function fire(ev) {
  const s = store.get();
  const cfg = s.alerts[ev.prayer];
  const name = PRAYER_NAMES[ev.prayer];
  const settingsForFmt = s;
  const time = fmtTime(new Date(ev.prayerAt), settingsForFmt);
  if (ev.type === 'pre') {
    await notify(`باقي ${cfg.pre} دقيقة على صلاة ${name}`, `موعد الصلاة ${time}`, `pre-${ev.prayer}`);
    toast(`باقي ${cfg.pre} دقيقة على صلاة ${name}`);
    const r = await playSound('chime', s.volume);
    if (!r.ok) toast(r.message);
    return;
  }
  await notify(`حان الآن موعد صلاة ${name}`, `${time} — ${s.location.name}`, `at-${ev.prayer}`);
  toast(`حان الآن موعد صلاة ${name}`);
  // Adhan ON  -> play the sound chosen for this prayer (full adhan or short alert, per `mode`).
  // Adhan OFF -> notification + the built-in short chime.
  const r = await playSound(cfg.adhan ? cfg.sound : 'chime', s.volume);
  if (!r.ok) toast(r.message);
}

/** Recomputes upcoming events and arms one timer for the earliest. Cancels any previous timer first. */
export function reschedule() {
  clearTimeout(timer);
  timer = null;
  next = null;
  const s = store.get();
  const anyOn = PRAYERS.some((p) => s.alerts[p].alert);
  if (!anyOn) return emit();
  let days;
  try {
    const ymd = localYMD(new Date(), s.location.tz);
    days = [computeDay(s, addDays(ymd, -1)), computeDay(s, ymd), computeDay(s, addDays(ymd, 1)), computeDay(s, addDays(ymd, 2))];
  } catch {
    return emit();
  }
  const nowMs = Date.now();
  const events = buildEvents(days, s.alerts, nowMs);
  if (!events.length) return emit();
  next = events[0];
  const delay = Math.max(0, next.at - nowMs);
  // setTimeout is capped at ~24.8 days; our horizon is < 3 days, but keep it safe.
  timer = setTimeout(async () => {
    const ev = next;
    if (ev && !isStale(ev, Date.now())) await fire(ev);
    reschedule();
  }, Math.min(delay, 2 ** 31 - 1));
  emit();
}

export function initAdhan() {
  store.subscribe(() => reschedule());
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') reschedule(); // timers may have been throttled while hidden
  });
  loadSounds().then(() => emit());
  reschedule();
}

/** Status text for the Settings screen. Never claims success unless a timer is really armed. */
export function scheduleStatus() {
  const s = store.get();
  if (!PRAYERS.some((p) => s.alerts[p].alert)) return { armed: false, text: 'لا توجد تنبيهات مفعّلة.' };
  if (!next || !timer) return { armed: false, text: 'تعذّرت جدولة التنبيه القادم (تحقق من الموقع).' };
  return {
    armed: true,
    text: `التنبيه القادم: صلاة ${PRAYER_NAMES[next.prayer]}${next.type === 'pre' ? ' (تنبيه مسبق)' : ''} — ${fmtTime(new Date(next.at), s)}`,
  };
}
