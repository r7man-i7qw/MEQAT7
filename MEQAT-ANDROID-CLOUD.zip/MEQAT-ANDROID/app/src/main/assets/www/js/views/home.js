import { store } from '../store.js';
import { h, clear, logoSVG, toast, nf } from '../dom.js';
import { APP, PRAYER_NAMES } from '../config.js';
import { METHODS, formatCountdown } from '../prayer.js';
import { localYMD, nextPrayerInfo, fmtTime, hijriDateString, gregorianDateString } from '../prayer-service.js';
import { useCurrentLocation, locationStatusText } from '../location.js';

export function initHome(root) {
  let tick = null;
  let current = null; // { info, ymdKey }
  let errorMsg = '';

  const el = {
    city: h('div', { class: 'city' }),
    status: h('div', { class: 'chip' }),
    hijri: h('div', { class: 'date' }),
    greg: h('div', { class: 'date sub' }),
    nextName: h('div', { class: 'next-name' }),
    nextTime: h('div', { class: 'next-time' }),
    countdown: h('div', { class: 'countdown', 'aria-live': 'off' }),
    list: h('div', { class: 'prayer-list' }),
    foot: h('div', { class: 'foot-note' }),
    banner: h('div', { class: 'banner', hidden: true }),
  };

  const refreshBtn = h('button', { class: 'btn ghost', onclick: async () => {
    const loc = store.get().location;
    if (loc.source === 'gps' || loc.source === 'default') {
      refreshBtn.disabled = true;
      const r = await useCurrentLocation();
      refreshBtn.disabled = false;
      if (!r.ok) toast(r.message, 5000);
      else toast('تم تحديث الموقع والمواقيت');
    }
    render(true);
  } }, 'تحديث المواقيت والموقع');

  root.append(
    h('header', { class: 'home-head' },
      h('div', { class: 'brand' }, h('span', { class: 'brand-logo' }, logoSVG(40, 'lg-home')), h('div', {}, h('div', { class: 'brand-name' }, APP.name), h('div', { class: 'brand-tag' }, APP.tagline))),
      el.city, el.status, el.hijri, el.greg,
    ),
    el.banner,
    h('section', { class: 'card next-card', 'aria-label': 'الصلاة القادمة' },
      h('div', { class: 'label' }, 'الصلاة القادمة'), el.nextName, el.nextTime, el.countdown),
    h('section', { class: 'card' }, el.list),
    h('div', { class: 'row-center' }, refreshBtn),
    el.foot,
  );

  function showBanner(text) {
    el.banner.hidden = !text;
    el.banner.textContent = text || '';
  }

  function render(force = false) {
    const s = store.get();
    const now = new Date();
    const tz = s.location.tz;
    el.city.textContent = s.location.name;
    el.status.textContent = locationStatusText(s.location);
    el.hijri.textContent = hijriDateString(now, tz);
    el.greg.textContent = gregorianDateString(now, tz);

    const ymd = localYMD(now, tz);
    const key = `${ymd.y}-${ymd.m}-${ymd.d}|${s.method}|${s.asr}|${s.location.lat},${s.location.lng}|${JSON.stringify(s.adjust)}`;
    try {
      if (force || !current || current.key !== key || now >= current.info.time) {
        const info = nextPrayerInfo(s, now);
        current = { info, key };
        store.setKV('lastTimes', { savedAt: Date.now(), times: Object.fromEntries(Object.entries(info.today).map(([k, v]) => [k, v.getTime()])), city: s.location.name, tz });
        errorMsg = '';
      }
      showBanner(s.location.source === 'default' ? 'هذا موقع افتراضي. اضغط «تحديث المواقيت والموقع» أو اختر مدينتك من الإعدادات لمواقيت دقيقة.' : '');
      renderList(current.info, s);
    } catch (e) {
      errorMsg = e.message === 'NO_SOLUTION' ? 'لا يمكن حساب بعض المواقيت عند هذا الموقع (خطوط عرض عالية).' : 'تعذّر حساب المواقيت.';
      renderSaved(s);
    }
    updateCountdown();
  }

  function renderList(info, s) {
    clear(el.list);
    const rows = ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'];
    for (const k of rows) {
      const isNext = k === info.key;
      el.list.append(
        h('div', { class: `prayer-row ${k === 'sunrise' ? 'sunrise' : ''} ${isNext ? 'next' : ''}` },
          h('span', { class: 'pname' }, PRAYER_NAMES[k], k === 'sunrise' ? h('small', {}, ' (ليست صلاة)') : null),
          h('span', { class: 'ptime' }, fmtTime(info.today[k], s))),
      );
    }
    el.nextName.textContent = `${PRAYER_NAMES[info.key]}${info.tomorrow ? ' (غدًا)' : ''}`;
    el.nextTime.textContent = fmtTime(info.time, s);
    el.foot.textContent = `طريقة الحساب: ${METHODS[s.method].name} • العصر: ${s.asr === 'hanafi' ? 'حنفي' : 'جمهور'} • تُحسب المواقيت على جهازك دون إنترنت.`;
  }

  function renderSaved(s) {
    const saved = store.getKV('lastTimes', null);
    clear(el.list);
    el.nextName.textContent = '—';
    el.nextTime.textContent = '';
    el.countdown.textContent = '';
    showBanner(errorMsg);
    if (!saved) {
      el.list.append(h('div', { class: 'empty' }, 'لا توجد مواقيت محفوظة.'));
      return;
    }
    el.list.append(h('div', { class: 'banner warn' }, `مواقيت محفوظة (آخر حساب ناجح: ${new Intl.DateTimeFormat('ar-EG', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(saved.savedAt))} — ${saved.city}). قد لا تنطبق على اليوم.`));
    for (const k of ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha']) {
      if (saved.times[k]) el.list.append(h('div', { class: 'prayer-row' }, h('span', { class: 'pname' }, PRAYER_NAMES[k]), h('span', { class: 'ptime' }, fmtTime(new Date(saved.times[k]), { ...s, location: { ...s.location, tz: saved.tz } }))));
    }
  }

  function updateCountdown() {
    if (!current) return;
    const ms = current.info.time.getTime() - Date.now();
    if (ms <= 0) {
      render(true); // moves to the next prayer automatically
      return;
    }
    el.countdown.textContent = formatCountdown(ms).replace(/\d/g, (d) => nf(d));
  }

  function start() {
    stop();
    render();
    tick = setInterval(() => {
      const s = store.get();
      const ymd = localYMD(new Date(), s.location.tz);
      const key = `${ymd.y}-${ymd.m}-${ymd.d}`;
      if (current && !current.key.startsWith(key)) render(true);
      else updateCountdown();
    }, 1000);
  }
  function stop() {
    clearInterval(tick);
    tick = null;
  }

  store.subscribe(() => {
    current = null;
    render(true);
  });
  document.addEventListener('visibilitychange', () => {
    if (!root.classList.contains('active')) return;
    if (document.visibilityState === 'visible') start();
    else stop();
  });

  return { onShow: start, onHide: stop };
}
