import { store } from '../store.js';
import { h, clear, toast, confirmDialog, nf } from '../dom.js';
import { APP, CONTACT, CITIES, PRAYER_NAMES } from '../config.js';
import { METHODS, PRAYERS } from '../prayer.js';
import { setCity, setCustom, useCurrentLocation, reverseGeocode, locationStatusText } from '../location.js';
import { availableSounds, hasAdhanFiles, playSound, stopSound, notificationState, requestNotifications, scheduleStatus } from '../adhan.js';
import { loadQuran, loadAdhkar, deleteQuran, deleteAdhkar, fmtDateTime, onDataChange, notifyDataChange } from '../data.js';
import { runQuranDownload, runAdhkarDownload, importQuranFile, importAdhkarFile } from '../data-actions.js';

export function initSettings(root) {
  const body = h('div', {});
  let dataNote = null;
  root.append(body);

  const section = (title, ...kids) => h('section', { class: 'card settings-sec' }, h('h2', {}, title), ...kids);
  const row = (label, control, hint) => h('div', { class: 'srow' }, h('div', { class: 'slabel' }, h('div', {}, label), hint ? h('div', { class: 'sub' }, hint) : null), control);
  const select = (value, options, onchange, label) => h('select', { class: 'input', 'aria-label': label, onchange: (e) => onchange(e.target.value) }, options.map(([v, t]) => h('option', { value: v, selected: String(v) === String(value) }, t)));
  const toggle = (checked, onchange, label) => h('input', { type: 'checkbox', class: 'switch', 'aria-label': label, checked: checked ? true : null, onchange: (e) => onchange(e.target.checked) });

  async function render() {
    const s = store.get();
    const [qrec, arec] = await Promise.all([loadQuran(), loadAdhkar()]);
    const frag = [];

    // ---- Location ----
    const locMsg = h('div', { class: 'banner', hidden: true });
    const lat = h('input', { class: 'input', inputmode: 'decimal', placeholder: 'خط العرض', 'aria-label': 'خط العرض', dir: 'ltr' });
    const lng = h('input', { class: 'input', inputmode: 'decimal', placeholder: 'خط الطول', 'aria-label': 'خط الطول', dir: 'ltr' });
    frag.push(section('الموقع',
      row('الموقع الحالي', h('div', { class: 'sval' }, s.location.name), locationStatusText(s.location)),
      h('div', { class: 'row-center' },
        h('button', { class: 'btn', onclick: async (e) => {
          e.target.disabled = true;
          const r = await useCurrentLocation();
          e.target.disabled = false;
          locMsg.hidden = false;
          locMsg.className = `banner ${r.ok ? '' : 'warn'}`;
          locMsg.textContent = r.ok ? 'تم تحديد موقعك وتحديث المواقيت.' : r.message;
        } }, 'استخدام موقعي الحالي'),
        s.location.source === 'gps' ? h('button', { class: 'btn ghost', onclick: async () => {
          if (!(await confirmDialog('لمعرفة اسم المدينة سيُرسل موقعك إلى خدمة OpenStreetMap مرة واحدة. هل تريد المتابعة؟', 'متابعة'))) return;
          const r = await reverseGeocode();
          toast(r.ok ? `المدينة: ${r.name}` : r.message, 4500);
        } }, 'معرفة اسم المدينة') : null),
      locMsg,
      row('اختيار المدينة يدويًا', select(CITIES.find((c) => c.name === s.location.name)?.id ?? '', [['', 'اختر مدينة…'], ...CITIES.map((c) => [c.id, c.name])], (id) => { const c = CITIES.find((x) => x.id === id); if (c) { setCity(c); toast(`تم اختيار ${c.name}`); } }, 'المدينة'), 'الإحداثيات تقريبية لمركز المدينة'),
      h('details', { 'data-key': 'custom-coords' }, h('summary', {}, 'إدخال إحداثيات مخصصة'), h('div', { class: 'srow' }, lat, lng), h('button', { class: 'btn ghost', onclick: () => { const r = setCustom({ lat: lat.value, lng: lng.value }); toast(r.ok ? 'تم حفظ الموقع' : r.message, 4500); } }, 'حفظ الموقع')),
      h('div', { class: 'sub' }, 'لا يُطلب إذن الموقع إلا عند الضغط على «استخدام موقعي الحالي»، ويبقى الموقع على جهازك.'),
    ));

    // ---- Prayer ----
    frag.push(section('الصلاة',
      row('طريقة الحساب', select(s.method, Object.entries(METHODS).map(([k, m]) => [k, m.name]), (v) => store.update({ method: v }), 'طريقة الحساب'), 'الافتراضي: الهيئة المصرية العامة للمساحة'),
      row('المذهب (للعصر)', select(s.asr, [['standard', 'الجمهور (ظل المثل)'], ['hanafi', 'الحنفي (ظل المثلين)']], (v) => store.update({ asr: v }), 'مذهب العصر')),
      row('تنسيق الوقت', select(s.timeFormat, [['12', '12 ساعة'], ['24', '24 ساعة']], (v) => store.update({ timeFormat: v }), 'تنسيق الوقت')),
      h('details', { 'data-key': 'adjust' }, h('summary', {}, 'تعديل المواقيت بالدقائق'),
        ...PRAYERS.map((p) => row(PRAYER_NAMES[p], select(s.adjust[p], Array.from({ length: 21 }, (_, i) => [i - 10, `${nf(i - 10)} د`]), (v) => store.update({ adjust: { [p]: Number(v) } }), `تعديل ${PRAYER_NAMES[p]}`)))),
    ));

    // ---- Adhan ----
    const sounds = availableSounds();
    const notif = notificationState();
    const status = h('div', { class: 'banner' }, scheduleStatus().text);
    const notifBtn = notif === 'granted' ? h('div', { class: 'sub' }, 'إذن الإشعارات: مُفعّل') : notif === 'unsupported' ? h('div', { class: 'banner warn' }, 'هذا المتصفح لا يدعم الإشعارات. ستعمل التنبيهات الصوتية داخل الصفحة المفتوحة فقط.') : h('button', { class: 'btn', onclick: async () => { const r = await requestNotifications(); toast(r === 'granted' ? 'تم تفعيل الإشعارات' : 'لم يتم منح إذن الإشعارات'); render(); } }, notif === 'denied' ? 'الإشعارات محظورة (فعّلها من إعدادات المتصفح)' : 'السماح بالإشعارات');
    if (notif === 'denied') notifBtn.disabled = true;
    const prayerCards = PRAYERS.map((p) => {
      const a = s.alerts[p];
      const soundsForMode = sounds.filter((x) => (a.mode === 'full' ? x.kind === 'adhan' : x.kind === 'short'));
      const upd = (patch) => store.update({ alerts: { [p]: patch } });
      return h('details', { class: 'prayer-set', 'data-key': `alert-${p}` },
        h('summary', {}, `${PRAYER_NAMES[p]} ${a.alert ? '— مُفعّل' : ''}`),
        row('تنبيه', toggle(a.alert, (v) => upd({ alert: v }), `تفعيل تنبيه ${PRAYER_NAMES[p]}`)),
        row('تشغيل الصوت عند الدخول', toggle(a.adhan, (v) => upd({ adhan: v }), `تشغيل الصوت للصلاة ${PRAYER_NAMES[p]}`), 'عند الإيقاف: إشعار مع نغمة قصيرة'),
        row('نوع الصوت', select(a.mode, [['short', 'تنبيه قصير'], ['full', 'أذان كامل']], (v) => upd({ mode: v, sound: v === 'full' ? (sounds.find((x) => x.kind === 'adhan')?.id ?? 'chime') : 'chime' }), 'نوع الصوت'), a.mode === 'full' && !hasAdhanFiles() ? 'لا توجد ملفات أذان في التطبيق بعد' : null),
        row(p === 'fajr' ? 'صوت الفجر' : 'الصوت', select(a.sound, (soundsForMode.length ? soundsForMode : [{ id: 'chime', name: 'تنبيه قصير (نغمة مدمجة)' }]).map((x) => [x.id, x.name]), (v) => upd({ sound: v }), 'الصوت')),
        row('معاينة', h('div', { class: 'row-center' }, h('button', { class: 'btn ghost', onclick: async () => { const r = await playSound(a.sound); if (!r.ok) toast(r.message); } }, 'تشغيل'), h('button', { class: 'btn ghost', onclick: stopSound }, 'إيقاف'))),
        row('تنبيه قبل الصلاة', select(a.pre, [[0, 'بدون'], [5, '٥ دقائق'], [10, '١٠ دقائق'], [15, '١٥ دقيقة'], [20, '٢٠ دقيقة'], [30, '٣٠ دقيقة']], (v) => upd({ pre: Number(v) }), 'التنبيه المسبق')),
      );
    });
    const vol = h('input', { type: 'range', min: '0', max: '1', step: '0.05', value: String(s.volume), 'aria-label': 'مستوى صوت التنبيه', onchange: (e) => store.update({ volume: Number(e.target.value) }) });
    frag.push(section('الأذان والتنبيهات',
      h('div', { class: 'banner warn' }, 'مهم: هذا موقع ويب. التنبيهات تعمل والمتصفح أو التطبيق المثبّت مفتوح أو حيّ في الخلفية. لا يمكن لأي موقع ضمان تشغيل الأذان والجهاز مقفل أو بعد إغلاق المتصفح، خصوصًا مع وضع توفير الطاقة ومتصفح iPhone.'),
      notifBtn, status,
      row('مستوى صوت التنبيه', vol, 'يُطبَّق على الأصوات داخل الصفحة'),
      ...prayerCards,
      h('div', { class: 'sub' }, sounds.length > 1 ? `الأصوات المتاحة: ${nf(sounds.length)}` : 'لا تتضمن النسخة أصوات أذان مرخّصة بعد. لإضافتها ضع ملفات مرخّصة داخل مجلد sounds وسجّلها في sounds/manifest.json (التفاصيل في README).'),
    ));

    // ---- Appearance ----
    frag.push(section('المظهر',
      row('السمة', select(s.theme, [['system', 'اتباع النظام'], ['light', 'فاتح'], ['dark', 'داكن']], (v) => store.update({ theme: v }), 'السمة')),
      row('حجم خط القرآن', select(s.quranFontSize, [22, 26, 30, 36, 42, 48].map((n) => [n, nf(n)]), (v) => store.update({ quranFontSize: Number(v) }), 'حجم خط القرآن')),
      row('حجم خط الأذكار', select(s.adhkarFontSize, [20, 24, 26, 30, 36, 42].map((n) => [n, nf(n)]), (v) => store.update({ adhkarFontSize: Number(v) }), 'حجم خط الأذكار')),
      row('اهتزاز عند عدّ الأذكار', toggle(s.vibrate, (v) => store.update({ vibrate: v }), 'اهتزاز')),
      row('تصحيح الانحراف المغناطيسي (درجات)', h('input', { class: 'input small-in', type: 'number', step: '0.5', min: '-30', max: '30', value: String(s.declination), dir: 'ltr', 'aria-label': 'الانحراف المغناطيسي', onchange: (e) => store.update({ declination: Math.max(-30, Math.min(30, Number(e.target.value) || 0)) }) }), 'موجب إذا كان الشمال المغناطيسي شرق الشمال الحقيقي. يُضاف لقراءة البوصلة. القيمة المحلية تجدها في حاسبة NOAA للانحراف المغناطيسي.'),
    ));

    // ---- Data ----
    const dataMsg = h('div', { class: 'banner data-msg', hidden: true });
    const paint = (el, r) => { el.hidden = false; el.className = `banner data-msg ${r.ok ? '' : 'warn'}`; el.replaceChildren(r.message, ...(r.details || []).map((d) => h('div', { class: 'small' }, d))); };
    // The view re-renders after data changes, so the note is kept in `dataNote` and painted into the current element.
    const say = (r) => { dataNote = r; const cur = body.querySelector('.data-msg') || dataMsg; paint(cur, r); };
    if (dataNote) paint(dataMsg, dataNote);
    const qprog = h('progress', { max: '1', value: '0', hidden: true });
    const pickFile = (cb) => { const i = h('input', { type: 'file', accept: '.json,application/json', hidden: true }); i.addEventListener('change', async () => { if (i.files[0]) say(await cb(i.files[0])); }); document.body.append(i); i.click(); setTimeout(() => i.remove(), 60000); };
    frag.push(section('البيانات',
      row('القرآن الكريم', h('div', { class: 'sval' }, qrec ? 'متوفر دون إنترنت' : 'غير منزَّل'), qrec ? `${qrec.data.source} • ${fmtDateTime(qrec.savedAt)} • بصمة: ${qrec.hash.slice(0, 12)}` : null),
      h('div', { class: 'row-center' },
        h('button', { class: 'btn', onclick: async (e) => { e.target.disabled = true; qprog.hidden = false; say({ ok: true, message: 'جارٍ تنزيل القرآن وفحصه…' }); const r = await runQuranDownload((p) => (qprog.value = p)); qprog.hidden = true; e.target.disabled = false; say(r); } }, qrec ? 'إعادة تنزيل القرآن' : 'تنزيل القرآن'),
        h('button', { class: 'btn ghost', onclick: () => pickFile(importQuranFile) }, 'استيراد ملف')),
      qprog,
      row('الأذكار', h('div', { class: 'sval' }, arec ? 'متوفرة دون إنترنت' : 'غير منزَّلة'), arec ? `${arec.data.source} • ${fmtDateTime(arec.savedAt)}` : null),
      h('div', { class: 'row-center' },
        h('button', { class: 'btn', onclick: async (e) => { e.target.disabled = true; say({ ok: true, message: 'جارٍ تنزيل الأذكار وفحصها…' }); const r = await runAdhkarDownload(); e.target.disabled = false; say(r); } }, arec ? 'إعادة تنزيل الأذكار' : 'تنزيل الأذكار'),
        h('button', { class: 'btn ghost', onclick: () => pickFile(importAdhkarFile) }, 'استيراد ملف')),
      dataMsg,
      h('div', { class: 'row-center' },
        h('button', { class: 'btn ghost', onclick: async () => {
          if (!(await confirmDialog('حذف الملفات المؤقتة (ذاكرة التخزين المؤقت للتطبيق). لن تُحذف إعداداتك ولا بيانات القرآن والأذكار.', 'حذف'))) return;
          try { const keys = await caches.keys(); await Promise.all(keys.map((k) => caches.delete(k))); toast('تم حذف الملفات المؤقتة. سيُعاد تحميلها عند الاتصال.'); } catch { toast('تعذّر حذف الملفات المؤقتة'); }
        } }, 'حذف الملفات المؤقتة'),
        h('button', { class: 'btn danger', onclick: async () => {
          if (!(await confirmDialog('سيتم مسح كل البيانات المحلية: الإعدادات، العلامات المرجعية، آخر موضع قراءة، تقدم الأذكار، وبيانات القرآن والأذكار المنزَّلة. لا يمكن التراجع.', 'مسح الكل', true))) return;
          store.clearAll();
          try { await deleteQuran(); await deleteAdhkar(); } catch { /* ignore */ }
          notifyDataChange();
          toast('تم مسح البيانات المحلية');
          render();
        } }, 'مسح البيانات المحلية')),
      h('div', { class: 'sub' }, 'الخصوصية: لا حساب ولا إعلانات ولا تتبّع. تُحفظ إعداداتك وبياناتك على جهازك فقط. الاتصال بالإنترنت لا يحدث إلا عند تنزيل القرآن/الأذكار (وعند معرفة اسم المدينة إذا اخترت ذلك).'),
    ));

    // ---- About ----
    const wa = CONTACT.whatsappNumber ? h('a', { class: 'btn', href: `https://wa.me/${CONTACT.whatsappNumber}?text=${encodeURIComponent(CONTACT.whatsappMessage)}`, target: '_blank', rel: 'noopener noreferrer' }, 'تواصل عبر WhatsApp') : null;
    frag.push(section('عن التطبيق',
      row('اسم التطبيق', h('div', { class: 'sval' }, APP.name)),
      row('الشعار', h('div', { class: 'sval' }, APP.tagline)),
      row('إعداد وتطوير', h('div', { class: 'sval' }, APP.developer)),
      row('Instagram', h('a', { href: APP.instagram.url, target: '_blank', rel: 'noopener noreferrer', dir: 'ltr' }, APP.instagram.handle)),
      wa ? h('div', { class: 'row-center' }, wa) : null,
      row('الإصدار', h('div', { class: 'sval', dir: 'ltr' }, APP.version)),
    ));

    clear(body);
    body.append(h('h1', { class: 'page-title' }, 'الإعدادات'), ...frag);
  }

  let rendering = false;
  const safeRender = async () => {
    if (rendering) return;
    rendering = true;
    const openKeys = [...body.querySelectorAll('details[open][data-key]')].map((n) => n.dataset.key);
    const y = window.scrollY;
    try { await render(); } finally { rendering = false; }
    body.querySelectorAll('details[data-key]').forEach((d) => { if (openKeys.includes(d.dataset.key)) d.open = true; });
    window.scrollTo(0, y);
  };

  onDataChange(() => { if (root.classList.contains('active')) safeRender(); });
  store.subscribe(() => { if (root.classList.contains('active')) safeRender(); });
  safeRender();
  return {
    onShow: safeRender,
    onHide: stopSound,
  };
}
