// User-facing data actions (download / import / delete) shared by the Quran, Adhkar and Settings screens.
import { downloadQuran, parseAnyQuranJSON } from './quran-sources.js';
import { validateQuran } from './quran-validate.js';
import { downloadAdhkar, parseAdhkar, validateAdhkar } from './adhkar-source.js';
import { saveQuran, saveAdhkar, notifyDataChange } from './data.js';

const OFFLINE_MSG = 'لا يوجد اتصال بالإنترنت. اتصل بالشبكة ثم أعد المحاولة، أو استورد ملف البيانات من جهازك من الإعدادات.';

let quranBusy = false;
export async function runQuranDownload(onProgress) {
  if (quranBusy) return { ok: false, message: 'التنزيل جارٍ بالفعل.' };
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return { ok: false, message: OFFLINE_MSG };
  quranBusy = true;
  try {
    const { data } = await downloadQuran({ onProgress });
    await saveQuran(data);
    notifyDataChange();
    return { ok: true, message: 'تم تنزيل القرآن الكريم وفحصه وحفظه للقراءة دون إنترنت.' };
  } catch (e) {
    return { ok: false, message: e.message || 'فشل التنزيل', details: e.details };
  } finally {
    quranBusy = false;
  }
}

let adhkarBusy = false;
export async function runAdhkarDownload() {
  if (adhkarBusy) return { ok: false, message: 'التنزيل جارٍ بالفعل.' };
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return { ok: false, message: OFFLINE_MSG };
  adhkarBusy = true;
  try {
    const data = await downloadAdhkar();
    await saveAdhkar(data);
    notifyDataChange();
    return { ok: true, message: 'تم تنزيل الأذكار وفحصها وحفظها للاستخدام دون إنترنت.' };
  } catch (e) {
    return { ok: false, message: `تعذّر تنزيل الأذكار: ${e.message || e}` };
  } finally {
    adhkarBusy = false;
  }
}

async function readJSONFile(file) {
  if (file.size > 40 * 1024 * 1024) throw new Error('الملف كبير جدًا');
  return JSON.parse(await file.text());
}

export async function importQuranFile(file) {
  try {
    const surahs = parseAnyQuranJSON(await readJSONFile(file));
    const data = { source: `ملف مستورد: ${file.name}`, sourceUrl: '', fetchedAt: Date.now(), surahs };
    const v = validateQuran(data);
    if (!v.ok) return { ok: false, message: `الملف لم يجتز فحص السلامة: ${v.errors.join('؛ ')}` };
    await saveQuran(data);
    notifyDataChange();
    return { ok: true, message: 'تم استيراد القرآن وفحصه وحفظه.' };
  } catch (e) {
    return { ok: false, message: `تعذّر استيراد الملف: ${e.message}` };
  }
}

export async function importAdhkarFile(file) {
  try {
    const cats = parseAdhkar(await readJSONFile(file));
    const v = validateAdhkar(cats);
    if (!v.ok) return { ok: false, message: `الملف لم يجتز الفحص: ${v.errors.join('؛ ')}` };
    await saveAdhkar({ source: `ملف مستورد: ${file.name}`, sourceUrl: '', fetchedAt: Date.now(), categories: cats });
    notifyDataChange();
    return { ok: true, message: 'تم استيراد الأذكار وفحصها وحفظها.' };
  } catch (e) {
    return { ok: false, message: `تعذّر استيراد الملف: ${e.message}` };
  }
}
