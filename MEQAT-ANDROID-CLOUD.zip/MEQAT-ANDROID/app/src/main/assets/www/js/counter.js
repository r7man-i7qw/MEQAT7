// Adhkar counter logic (pure). Progress is stored per day: a new day starts from zero.

export function dayKey(date = new Date()) {
  const p = (n) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${p(date.getMonth() + 1)}-${p(date.getDate())}`;
}

export const itemKey = (catId, index) => `${catId}:${index}`;

/** progress shape: { day: 'YYYY-MM-DD', counts: { [itemKey]: number } } */
export function freshProgress(today) {
  return { day: today, counts: {} };
}

export function normalizeProgress(progress, today) {
  if (!progress || progress.day !== today || typeof progress.counts !== 'object') return freshProgress(today);
  return progress;
}

export function getCount(progress, key) {
  return progress.counts[key] || 0;
}

export function isDone(progress, key, target) {
  return target != null && getCount(progress, key) >= target;
}

/** Increment; returns a new progress object. Does nothing past the target. */
export function tap(progress, key, target) {
  const cur = getCount(progress, key);
  if (target != null && cur >= target) return progress;
  return { ...progress, counts: { ...progress.counts, [key]: cur + 1 } };
}

export function resetItem(progress, key) {
  const counts = { ...progress.counts };
  delete counts[key];
  return { ...progress, counts };
}

export function resetCategory(progress, catId) {
  const counts = {};
  for (const [k, v] of Object.entries(progress.counts)) if (!k.startsWith(`${catId}:`)) counts[k] = v;
  return { ...progress, counts };
}

/** Fraction 0..1 of items in a category that are complete (items without a fixed count never count as complete). */
export function categoryProgress(progress, cat) {
  const done = cat.items.reduce((n, it, i) => n + (isDone(progress, itemKey(cat.id, i), it.count) ? 1 : 0), 0);
  return { done, total: cat.items.length };
}
