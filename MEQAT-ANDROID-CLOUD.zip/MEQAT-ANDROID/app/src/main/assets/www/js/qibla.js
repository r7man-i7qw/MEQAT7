// Qibla geometry. Pure functions.

export const KAABA = { lat: 21.4225, lng: 39.8262 };
const D2R = Math.PI / 180;

/** Initial great-circle bearing (degrees from TRUE north, 0-360) from a point to the Kaaba. */
export function qiblaBearing(lat, lng) {
  const p1 = lat * D2R;
  const p2 = KAABA.lat * D2R;
  const dl = (KAABA.lng - lng) * D2R;
  const y = Math.sin(dl) * Math.cos(p2);
  const x = Math.cos(p1) * Math.sin(p2) - Math.sin(p1) * Math.cos(p2) * Math.cos(dl);
  return (Math.atan2(y, x) / D2R + 360) % 360;
}

export function distanceKm(lat, lng) {
  const R = 6371.0088;
  const p1 = lat * D2R;
  const p2 = KAABA.lat * D2R;
  const dp = p2 - p1;
  const dl = (KAABA.lng - lng) * D2R;
  const a = Math.sin(dp / 2) ** 2 + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

/** Signed shortest difference a-b in degrees, range [-180, 180). */
export function angleDiff(a, b) {
  return ((((a - b) % 360) + 540) % 360) - 180;
}

/** Circular low-pass filter for compass headings. */
export function smoothHeading(prev, next, alpha = 0.2) {
  if (prev == null) return next;
  return (prev + alpha * angleDiff(next, prev) + 360) % 360;
}

/** Standard deviation (degrees) of a list of headings, circular-safe. */
export function headingJitter(samples) {
  if (samples.length < 4) return 0;
  const ref = samples[samples.length - 1];
  const diffs = samples.map((s) => angleDiff(s, ref));
  const mean = diffs.reduce((a, b) => a + b, 0) / diffs.length;
  return Math.sqrt(diffs.reduce((a, b) => a + (b - mean) ** 2, 0) / diffs.length);
}

/** Convert a magnetic heading to true heading. Declination is positive when magnetic north is east of true north. */
export function toTrueHeading(magnetic, declination = 0) {
  return (magnetic + declination + 360) % 360;
}
