// Prayer time calculation (standard astronomical method, same family as PrayTimes.org).
// Pure functions: no DOM, no storage. All angles in degrees.

const D2R = Math.PI / 180;
const sin = (d) => Math.sin(d * D2R);
const cos = (d) => Math.cos(d * D2R);
const tan = (d) => Math.tan(d * D2R);
const asin = (x) => Math.asin(x) / D2R;
const acos = (x) => Math.acos(x) / D2R;
const atan2 = (y, x) => Math.atan2(y, x) / D2R;
const acot = (x) => Math.atan(1 / x) / D2R;
const fix = (a, b) => {
  a -= b * Math.floor(a / b);
  return a < 0 ? a + b : a;
};

export const PRAYERS = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];

// fajr/isha: sun angle below the horizon. ishaMinutes: fixed minutes after Maghrib.
export const METHODS = {
  egypt: { name: 'الهيئة المصرية العامة للمساحة', fajr: 19.5, isha: 17.5 },
  mwl: { name: 'رابطة العالم الإسلامي', fajr: 18, isha: 17 },
  makkah: { name: 'أم القرى (مكة المكرمة)', fajr: 18.5, ishaMinutes: 90, ishaMinutesRamadan: 120 },
  isna: { name: 'الجمعية الإسلامية لأمريكا الشمالية (ISNA)', fajr: 15, isha: 15 },
  karachi: { name: 'جامعة العلوم الإسلامية بكراتشي', fajr: 18, isha: 18 },
};

const HORIZON_ANGLE = 0.833; // sunrise/sunset incl. refraction and solar radius

export function julian(y, m, d) {
  if (m <= 2) {
    y -= 1;
    m += 12;
  }
  const A = Math.floor(y / 100);
  const B = 2 - A + Math.floor(A / 4);
  return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + B - 1524.5;
}

function sunPosition(jd) {
  const D = jd - 2451545.0;
  const g = fix(357.529 + 0.98560028 * D, 360);
  const q = fix(280.459 + 0.98564736 * D, 360);
  const L = fix(q + 1.915 * sin(g) + 0.02 * sin(2 * g), 360);
  const e = 23.439 - 0.00000036 * D;
  const RA = atan2(cos(e) * sin(L), cos(L)) / 15;
  const eqt = q / 15 - fix(RA, 24);
  const decl = asin(sin(e) * sin(L));
  return { decl, eqt };
}

/**
 * @param {object} o
 * @param {number} o.y @param {number} o.m (1-12) @param {number} o.d  local civil date at the location
 * @param {number} o.lat @param {number} o.lng
 * @param {number} o.tz  UTC offset in hours that applies on that date at the location
 * @param {string} [o.method] key of METHODS
 * @param {'standard'|'hanafi'} [o.asr]
 * @param {Record<string, number>} [o.adjust] per-prayer minute offsets
 * @param {boolean} [o.ramadan] only used by methods with a Ramadan Isha rule
 * @returns {{fajr:Date,sunrise:Date,dhuhr:Date,asr:Date,maghrib:Date,isha:Date}}
 */
export function computeTimes({ y, m, d, lat, lng, tz, method = 'egypt', asr = 'standard', adjust = {}, ramadan = false }) {
  const M = METHODS[method];
  if (!M) throw new Error(`Unknown calculation method: ${method}`);
  if (![y, m, d, lat, lng, tz].every(Number.isFinite)) throw new Error('Invalid input');

  const jd = julian(y, m, d) - lng / 360;
  const midDay = (t) => fix(12 - sunPosition(jd + t).eqt, 24);
  const angleTime = (angle, t, ccw) => {
    const { decl } = sunPosition(jd + t);
    const noon = midDay(t);
    const v = acos((-sin(angle) - sin(decl) * sin(lat)) / (cos(decl) * cos(lat))) / 15;
    return noon + (ccw ? -v : v);
  };
  const asrTime = (factor, t) => {
    const { decl } = sunPosition(jd + t);
    const angle = -acot(factor + tan(Math.abs(lat - decl)));
    return angleTime(angle, t, false);
  };

  let t = { fajr: 5, sunrise: 6, dhuhr: 12, asr: 13, sunset: 18, maghrib: 18, isha: 18 };
  let r = t;
  for (let i = 0; i < 2; i++) {
    const p = {};
    for (const k of Object.keys(t)) p[k] = t[k] / 24;
    r = {
      fajr: angleTime(M.fajr, p.fajr, true),
      sunrise: angleTime(HORIZON_ANGLE, p.sunrise, true),
      dhuhr: midDay(p.dhuhr),
      asr: asrTime(asr === 'hanafi' ? 2 : 1, p.asr),
      sunset: angleTime(HORIZON_ANGLE, p.sunset, false),
      maghrib: angleTime(HORIZON_ANGLE, p.maghrib, false),
      isha: M.isha != null ? angleTime(M.isha, p.isha, false) : 0,
    };
    t = r;
  }

  const shift = tz - lng / 15;
  const out = {};
  for (const k of ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha']) out[k] = r[k] + shift;
  if (M.ishaMinutes != null) {
    out.isha = out.maghrib + (ramadan && M.ishaMinutesRamadan ? M.ishaMinutesRamadan : M.ishaMinutes) / 60;
  }
  for (const k of PRAYERS) out[k] += (Number(adjust[k]) || 0) / 60;

  const base = Date.UTC(y, m - 1, d) - tz * 3600e3;
  const result = {};
  for (const k of Object.keys(out)) {
    if (!Number.isFinite(out[k])) {
      throw new Error('NO_SOLUTION'); // e.g. extreme latitudes where the sun never reaches the angle
    }
    result[k] = new Date(Math.round((base + out[k] * 3600e3) / 60000) * 60000);
  }
  return result;
}

/** Pick the next prayer (not sunrise) after `now`. Returns null if `tomorrowTimes` is needed. */
export function findNextPrayer(todayTimes, now) {
  for (const k of PRAYERS) {
    if (todayTimes[k].getTime() > now.getTime()) return { key: k, time: todayTimes[k] };
  }
  return null;
}

export function formatCountdown(ms) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const pad = (n) => String(n).padStart(2, '0');
  return `${pad(h)}:${pad(m)}:${pad(s)}`;
}
