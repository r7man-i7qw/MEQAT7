// Bridges settings + location + the pure calculator. Handles time zones and day boundaries.
import { computeTimes, findNextPrayer } from './prayer.js';

export function deviceTimeZone() {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
  } catch {
    return 'UTC';
  }
}

/** Civil date (y, m, d) of `date` in time zone `tz`. */
export function localYMD(date, tz) {
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(date);
  const g = (t) => Number(parts.find((p) => p.type === t).value);
  return { y: g('year'), m: g('month'), d: g('day') };
}

/** UTC offset (hours) of `tz` at the instant `ms`. */
export function tzOffsetHours(tz, ms) {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: tz, hourCycle: 'h23', year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric',
  }).formatToParts(new Date(ms));
  const g = (t) => Number(parts.find((p) => p.type === t).value);
  const asUTC = Date.UTC(g('year'), g('month') - 1, g('day'), g('hour'), g('minute'), g('second'));
  return (asUTC - Math.floor(ms / 1000) * 1000) / 3600000;
}

export function isRamadan(ymd) {
  try {
    const parts = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura', { month: 'numeric' }).formatToParts(new Date(Date.UTC(ymd.y, ymd.m - 1, ymd.d, 12)));
    return Number(parts.find((p) => p.type === 'month').value) === 9;
  } catch {
    return false;
  }
}

export function computeDay(settings, ymd) {
  const { lat, lng, tz } = settings.location;
  const offset = tzOffsetHours(tz, Date.UTC(ymd.y, ymd.m - 1, ymd.d, 12));
  return computeTimes({
    ...ymd, lat, lng, tz: offset, method: settings.method, asr: settings.asr, adjust: settings.adjust, ramadan: isRamadan(ymd),
  });
}

export function addDays(ymd, n) {
  const d = new Date(Date.UTC(ymd.y, ymd.m - 1, ymd.d + n));
  return { y: d.getUTCFullYear(), m: d.getUTCMonth() + 1, d: d.getUTCDate() };
}

/** @returns {{key:string,time:Date,today:object,tomorrow:boolean}} */
export function nextPrayerInfo(settings, now = new Date()) {
  const ymd = localYMD(now, settings.location.tz);
  const today = computeDay(settings, ymd);
  const next = findNextPrayer(today, now);
  if (next) return { ...next, today, tomorrow: false };
  const t2 = computeDay(settings, addDays(ymd, 1));
  return { key: 'fajr', time: t2.fajr, today, tomorrow: true };
}

export function fmtTime(date, settings) {
  return new Intl.DateTimeFormat('ar-EG', {
    timeZone: settings.location.tz, hour: 'numeric', minute: '2-digit', hour12: settings.timeFormat === '12',
  }).format(date);
}

export function hijriDateString(date, tz) {
  try {
    return new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', { timeZone: tz, day: 'numeric', month: 'long', year: 'numeric' }).format(date);
  } catch {
    return '';
  }
}

export function gregorianDateString(date, tz) {
  return new Intl.DateTimeFormat('ar-EG', { timeZone: tz, weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(date);
}
