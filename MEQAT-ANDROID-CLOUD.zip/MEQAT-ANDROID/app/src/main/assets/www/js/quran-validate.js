// Structural validation of downloaded Quran data + Arabic text helpers.
// IMPORTANT: this file contains NO Quranic text. It only holds the canonical ayah COUNT per surah,
// which is used to reject incomplete or corrupted downloads. The text itself always comes from the source.

// Number of ayat in each of the 114 surahs (standard Hafs/Kufan numbering). Total = 6236.
export const AYAH_COUNTS = [
  7, 286, 200, 176, 120, 165, 206, 75, 129, 109, 123, 111, 43, 52, 99, 128, 111, 110, 98, 135, 112, 78, 118, 64, 77, 227,
  93, 88, 69, 60, 34, 30, 73, 54, 45, 83, 182, 88, 75, 85, 54, 53, 89, 59, 37, 35, 38, 29, 18, 45, 60, 49, 62, 55, 78, 96,
  29, 22, 24, 13, 14, 11, 11, 18, 12, 12, 30, 52, 52, 44, 28, 28, 20, 56, 40, 31, 50, 40, 46, 42, 29, 19, 36, 25, 22, 17,
  19, 26, 30, 20, 15, 21, 11, 8, 8, 19, 5, 8, 8, 11, 11, 8, 3, 9, 5, 4, 7, 3, 6, 3, 5, 4, 5, 6,
];
export const TOTAL_AYAT = 6236;

/**
 * Normalized dataset shape:
 * { source: string, sourceUrl: string, fetchedAt: number,
 *   surahs: [{ n: number, name: string, type: 'makki'|'madani'|null, ayahs: string[], pages: number[]|null }] }
 * @returns {{ok: boolean, errors: string[]}}
 */
export function validateQuran(data) {
  const errors = [];
  if (!data || !Array.isArray(data.surahs)) return { ok: false, errors: ['بنية البيانات غير صحيحة'] };
  if (data.surahs.length !== 114) errors.push(`عدد السور ${data.surahs.length} بدل 114`);
  let total = 0;
  data.surahs.forEach((s, i) => {
    if (s.n !== i + 1) errors.push(`ترتيب السور غير صحيح عند ${i + 1}`);
    if (typeof s.name !== 'string' || !s.name.trim()) errors.push(`اسم السورة ${i + 1} مفقود`);
    if (!Array.isArray(s.ayahs)) {
      errors.push(`آيات السورة ${i + 1} مفقودة`);
      return;
    }
    if (s.ayahs.length !== AYAH_COUNTS[i]) errors.push(`عدد آيات السورة ${i + 1} هو ${s.ayahs.length} بدل ${AYAH_COUNTS[i]}`);
    total += s.ayahs.length;
    s.ayahs.forEach((t, j) => {
      if (typeof t !== 'string' || !/[؀-ۿ]/.test(t) || t.includes('�')) {
        errors.push(`نص الآية ${j + 1} من السورة ${i + 1} غير صالح`);
      }
    });
    if (s.pages && s.pages.length !== s.ayahs.length) errors.push(`بيانات الصفحات للسورة ${i + 1} غير متطابقة`);
  });
  if (total !== TOTAL_AYAT) errors.push(`إجمالي الآيات ${total} بدل ${TOTAL_AYAT}`);
  return { ok: errors.length === 0, errors: errors.slice(0, 8) };
}

const DIACRITICS = /[ؐ-ًؚ-ٰٟۖ-ۭـ࣓-ࣿ]/g;

/** Search-only normalization (never used to alter displayed text). */
export function normalizeArabic(str) {
  return String(str)
    .replace(DIACRITICS, '')
    .replace(/[ٱآأإ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه')
    .replace(/\s+/g, ' ')
    .trim();
}

const BASMALA_NORMALIZED = 'بسم الله الرحمن الرحيم';

/**
 * Some sources prepend the basmala to the first ayah of a surah. For display we show it as a
 * separate header line. The text is only split at a word boundary, never modified.
 * Returns { basmala: string|null, text: string }.
 */
export function splitBasmala(text, surahNumber, ayahNumber) {
  if (ayahNumber !== 1 || surahNumber === 1 || surahNumber === 9) return { basmala: null, text };
  const words = text.split(' ');
  if (words.length > 4 && normalizeArabic(words.slice(0, 4).join(' ')) === BASMALA_NORMALIZED) {
    return { basmala: words.slice(0, 4).join(' '), text: words.slice(4).join(' ') };
  }
  return { basmala: null, text };
}

export async function sha256Hex(str) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

export function quranFingerprintInput(data) {
  return data.surahs.map((s) => s.ayahs.join('\n')).join('\n');
}
