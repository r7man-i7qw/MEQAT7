// Pure scheduling logic for in-page alerts (no timers, no DOM).
import { PRAYERS } from './prayer.js';

/**
 * Builds the sorted list of future alert events.
 * @param {Array<Record<string, Date>>} days prayer times for consecutive days
 * @param {Record<string, {alert:boolean, pre:number}>} alerts per-prayer settings
 * @param {number} nowMs
 * @returns {Array<{id:string, prayer:string, type:'pre'|'at', at:number, prayerAt:number}>}
 */
export function buildEvents(days, alerts, nowMs) {
  const seen = new Set();
  const events = [];
  for (const day of days) {
    for (const p of PRAYERS) {
      const cfg = alerts[p];
      if (!cfg?.alert || !day[p]) continue;
      const t = day[p].getTime();
      const pre = Number(cfg.pre) || 0;
      const push = (type, at) => {
        const id = `${p}|${t}|${type}`;
        if (at > nowMs && !seen.has(id)) {
          seen.add(id);
          events.push({ id, prayer: p, type, at, prayerAt: t });
        }
      };
      if (pre > 0) push('pre', t - pre * 60000);
      push('at', t);
    }
  }
  return events.sort((a, b) => a.at - b.at);
}

/** An event is stale if the page was asleep and it is now long past (avoid late adhan). */
export function isStale(event, nowMs, graceMs = 90000) {
  return nowMs - event.at > graceMs;
}
