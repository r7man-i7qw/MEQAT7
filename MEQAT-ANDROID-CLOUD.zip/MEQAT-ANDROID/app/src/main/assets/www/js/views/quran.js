import { store } from '../store.js';
import { h, clear, nf, toast, debounce } from '../dom.js';
import { loadQuran, onDataChange } from '../data.js';
import { runQuranDownload } from '../data-actions.js';
import { normalizeArabic, splitBasmala } from '../quran-validate.js';

export function initQuran(root) {
  let rec = null; // { data, hash }
  let norm = null; // lazily built normalized ayahs for search
  let mode = 'index'; // 'index' | 'reader' | 'search' | 'bookmarks'
  let cur = null; // { s, a }
  let scrollHandler = null;
  const body = h('div', { class: 'quran-body' });
  root.append(body);

  const typeLabel = (t) => (t === 'makki' ? 'مكية' : t === 'madani' ? 'مدنية' : '');
  const bookmarks = () => store.getKV('bookmarks', []);
  const lastRead = () => store.getKV('lastRead', null);

  async function ensure() {
    rec = await loadQuran();
    norm = null;
    show(mode === 'reader' && rec ? 'reader' : mode);
  }

  // ---------- states ----------
  function renderMissing(msg) {
    clear(body);
    const prog = h('progress', { max: '1', value: '0', hidden: true });
    const out = h('div', { class: 'banner', hidden: !msg }, msg || '');
    const btn = h('button', { class: 'btn' }, 'تنزيل القرآن الكريم للقراءة دون إنترنت');
    btn.addEventListener('click', async () => {
      btn.disabled = true;
      prog.hidden = false;
      out.hidden = false;
      out.className = 'banner';
      out.textContent = 'جارٍ التنزيل والفحص…';
      const r = await runQuranDownload((p) => (prog.value = p));
      btn.disabled = false;
      prog.hidden = true;
      if (!r.ok) {
        out.className = 'banner warn';
        out.replaceChildren(r.message, ...(r.details || []).map((d) => h('div', { class: 'small' }, d)));
      }
    });
    body.append(
      h('h1', { class: 'page-title' }, 'القرآن الكريم'),
      h('section', { class: 'card center' },
        h('p', {}, 'بيانات القرآن غير متوفرة على هذا الجهاز بعد.'),
        h('p', { class: 'sub' }, 'سيُنزَّل النص من مصدر مفتوح ويُفحص (114 سورة، 6236 آية، وعدد آيات كل سورة) قبل حفظه، ثم تعمل القراءة دون إنترنت. لا يُرسل أي شيء عنك.'),
        btn, prog, out),
    );
  }

  // ---------- index ----------
  function renderIndex() {
    clear(body);
    const lr = lastRead();
    const filter = h('input', { type: 'search', class: 'input', placeholder: 'ابحث عن سورة بالاسم أو الرقم', 'aria-label': 'بحث في السور' });
    const list = h('div', { class: 'surah-list' });
    const fill = () => {
      const q = normalizeArabic(filter.value);
      clear(list);
      for (const s of rec.data.surahs) {
        if (q && !normalizeArabic(s.name).includes(q) && String(s.n) !== q) continue;
        list.append(h('button', { class: 'surah-item', onclick: () => open(s.n, 1) },
          h('span', { class: 'sn' }, nf(s.n)),
          h('span', { class: 'sname' }, s.name),
          h('span', { class: 'smeta' }, `${typeLabel(s.type)}${s.type ? ' • ' : ''}${nf(s.ayahs.length)} آية`)));
      }
      if (!list.children.length) list.append(h('div', { class: 'empty' }, 'لا توجد نتائج.'));
    };
    filter.addEventListener('input', debounce(fill, 120));
    body.append(
      h('h1', { class: 'page-title' }, 'القرآن الكريم'),
      lr ? h('button', { class: 'card resume', onclick: () => open(lr.s, lr.a) }, h('div', { class: 'label' }, 'العودة إلى آخر موضع'), h('div', { class: 'resume-name' }, `${rec.data.surahs[lr.s - 1].name} — آية ${nf(lr.a)}`)) : null,
      h('div', { class: 'toolbar' },
        h('button', { class: 'btn ghost', onclick: () => show('search') }, 'بحث في النص'),
        h('button', { class: 'btn ghost', onclick: () => show('bookmarks') }, `العلامات المرجعية (${nf(bookmarks().length)})`)),
      filter, list,
      h('div', { class: 'foot-note' }, `المصدر: ${rec.data.source}`),
    );
    fill();
  }

  // ---------- reader ----------
  function open(s, a = 1) {
    cur = { s, a };
    show('reader');
  }

  function renderReader() {
    clear(body);
    const { s: sn, a: target } = cur;
    const surah = rec.data.surahs[sn - 1];
    const fs = store.get().quranFontSize;
    const text = h('div', { class: 'mushaf', style: `font-size:${fs}px` });
    const pageLbl = h('span', { class: 'page-lbl' });
    let lastPage = null;

    // header
    const header = h('div', { class: 'surah-banner' }, h('div', { class: 'sb-name' }, surah.name), h('div', { class: 'sb-meta' }, `${typeLabel(surah.type)}${surah.type ? ' • ' : ''}${nf(surah.ayahs.length)} آية`));
    text.append(header);

    const first = splitBasmala(surah.ayahs[0], sn, 1);
    const showBasmala = sn !== 1 && sn !== 9;
    if (showBasmala) {
      // The basmala header line is never typed by us: it is either the prefix the source embedded in ayah 1,
      // or the text of ayah 1 of Al-Fatiha from the same downloaded dataset.
      const line = first.basmala || rec.data.surahs[0].ayahs[0];
      text.append(h('div', { class: 'basmala' }, line));
    }

    const bm = new Set(bookmarks().filter((b) => b.s === sn).map((b) => b.a));
    surah.ayahs.forEach((t, i) => {
      const n = i + 1;
      const shown = n === 1 ? first.text : t;
      const pg = surah.pages?.[i];
      if (pg && pg !== lastPage) {
        text.append(h('div', { class: 'page-divider' }, `صفحة ${nf(pg)}`));
        lastPage = pg;
      }
      const span = h('span', { class: `ayah ${bm.has(n) ? 'bm' : ''}`, 'data-a': String(n), 'data-p': pg ? String(pg) : '', tabindex: '0', role: 'button', 'aria-label': `آية ${n}` }, `${shown} `, h('span', { class: 'anum' }, `﴿${nf(n)}﴾`), ' ');
      span.addEventListener('click', () => ayahMenu(sn, n, span));
      span.addEventListener('keydown', (e) => (e.key === 'Enter' ? ayahMenu(sn, n, span) : null));
      text.append(span);
    });
    text.append(h('div', { class: 'surah-end' }, `— نهاية ${surah.name} —`));

    const prev = sn > 1 ? h('button', { class: 'btn ghost', onclick: () => open(sn - 1, 1) }, '‹ السورة السابقة') : h('span');
    const nextB = sn < 114 ? h('button', { class: 'btn ghost', onclick: () => open(sn + 1, 1) }, 'السورة التالية ›') : h('span');

    const gotoInput = h('input', { type: 'number', min: '1', max: String(surah.ayahs.length), class: 'input small-in', placeholder: 'آية', 'aria-label': 'رقم الآية' });
    gotoInput.addEventListener('keydown', (e) => e.key === 'Enter' && jump());
    function jump() {
      const n = Math.floor(Number(gotoInput.value));
      if (!n || n < 1 || n > surah.ayahs.length) return toast(`أدخل رقم آية من 1 إلى ${nf(surah.ayahs.length)}`);
      scrollToAyah(n);
    }

    body.append(
      h('div', { class: 'reader-bar' },
        h('button', { class: 'btn ghost', onclick: () => show('index') }, '‹ الفهرس'),
        pageLbl,
        h('div', { class: 'font-ctl' },
          h('button', { class: 'btn ghost', 'aria-label': 'تصغير الخط', onclick: () => store.update({ quranFontSize: Math.max(20, store.get().quranFontSize - 2) }) }, 'أ−'),
          h('button', { class: 'btn ghost', 'aria-label': 'تكبير الخط', onclick: () => store.update({ quranFontSize: Math.min(54, store.get().quranFontSize + 2) }) }, 'أ+'))),
      h('div', { class: 'toolbar' }, gotoInput, h('button', { class: 'btn ghost', onclick: jump }, 'اذهب'), h('select', { class: 'input', 'aria-label': 'انتقال إلى سورة', onchange: (e) => open(Number(e.target.value), 1) }, rec.data.surahs.map((s) => h('option', { value: s.n, selected: s.n === sn }, `${nf(s.n)}. ${s.name}`)))),
      text,
      h('div', { class: 'row-between' }, prev, nextB),
    );

    // remember last position while scrolling; stop listening when leaving the reader
    const scroller = document.scrollingElement;
    const save = debounce(() => {
      const a = topAyah(text);
      if (a) {
        store.setKV('lastRead', { s: sn, a });
        const el = text.querySelector(`[data-a="${a}"]`);
        pageLbl.textContent = el?.dataset.p ? `صفحة ${nf(el.dataset.p)}` : '';
      }
    }, 350);
    scrollHandler = () => save();
    scroller.addEventListener('scroll', scrollHandler, { passive: true });
    window.scrollTo(0, 0);
    requestAnimationFrame(() => {
      if (target > 1) scrollToAyah(target);
      else save();
    });
  }

  function topAyah(container) {
    for (const el of container.querySelectorAll('.ayah')) {
      if (el.getBoundingClientRect().bottom > 90) return Number(el.dataset.a);
    }
    return null;
  }

  function scrollToAyah(n) {
    const el = body.querySelector(`.ayah[data-a="${n}"]`);
    if (!el) return;
    el.scrollIntoView({ block: 'center', behavior: 'auto' });
    el.classList.add('flash');
    setTimeout(() => el.classList.remove('flash'), 1600);
  }

  function ayahMenu(s, a, span) {
    const marks = bookmarks();
    const idx = marks.findIndex((b) => b.s === s && b.a === a);
    if (idx >= 0) marks.splice(idx, 1);
    else marks.push({ s, a, ts: Date.now() });
    store.setKV('bookmarks', marks);
    span.classList.toggle('bm', idx < 0);
    toast(idx < 0 ? `تمت إضافة علامة مرجعية: ${rec.data.surahs[s - 1].name} آية ${nf(a)}` : 'تم حذف العلامة المرجعية');
  }

  // ---------- search ----------
  function renderSearch(initial = '') {
    clear(body);
    if (!norm) norm = rec.data.surahs.map((s) => s.ayahs.map(normalizeArabic));
    const input = h('input', { type: 'search', class: 'input', placeholder: 'اكتب كلمة أو جزءًا من آية (بدون تشكيل)', 'aria-label': 'بحث في القرآن', value: initial });
    const results = h('div', { class: 'results' });
    const run = () => {
      const q = normalizeArabic(input.value);
      clear(results);
      if (q.length < 2) return results.append(h('div', { class: 'empty' }, 'اكتب حرفين على الأقل.'));
      let count = 0;
      let total = 0;
      outer: for (let si = 0; si < norm.length; si++) {
        for (let ai = 0; ai < norm[si].length; ai++) {
          if (norm[si][ai].includes(q)) {
            total++;
            if (count < 80) {
              count++;
              const s = rec.data.surahs[si];
              results.append(h('button', { class: 'result', onclick: () => open(si + 1, ai + 1) }, h('div', { class: 'result-ref' }, `${s.name} • آية ${nf(ai + 1)}`), h('div', { class: 'result-text' }, s.ayahs[ai])));
            }
          }
        }
        if (total > 2000) break outer;
      }
      if (!total) results.append(h('div', { class: 'empty' }, 'لا توجد نتائج.'));
      else results.prepend(h('div', { class: 'sub' }, total > 80 ? `عرض أول ${nf(80)} نتيجة من ${nf(total)}${total > 2000 ? '+' : ''}` : `${nf(total)} نتيجة`));
    };
    input.addEventListener('input', debounce(run, 250));
    body.append(h('div', { class: 'reader-bar' }, h('button', { class: 'btn ghost', onclick: () => show('index') }, '‹ الفهرس'), h('h2', { class: 'bar-title' }, 'بحث')), input, results);
    input.focus();
    if (initial) run();
  }

  // ---------- bookmarks ----------
  function renderBookmarks() {
    clear(body);
    const marks = bookmarks().slice().sort((a, b) => b.ts - a.ts);
    body.append(h('div', { class: 'reader-bar' }, h('button', { class: 'btn ghost', onclick: () => show('index') }, '‹ الفهرس'), h('h2', { class: 'bar-title' }, 'العلامات المرجعية')));
    if (!marks.length) return body.append(h('div', { class: 'empty' }, 'لا توجد علامات مرجعية. اضغط على أي آية أثناء القراءة لإضافة علامة.'));
    for (const m of marks) {
      const s = rec.data.surahs[m.s - 1];
      body.append(h('div', { class: 'card bm-row' },
        h('button', { class: 'bm-open', onclick: () => open(m.s, m.a) }, h('div', { class: 'result-ref' }, `${s.name} • آية ${nf(m.a)}`), h('div', { class: 'result-text' }, s.ayahs[m.a - 1])),
        h('button', { class: 'btn ghost danger-text', 'aria-label': 'حذف العلامة', onclick: () => { store.setKV('bookmarks', bookmarks().filter((b) => !(b.s === m.s && b.a === m.a))); renderBookmarks(); } }, 'حذف')));
    }
  }

  function show(m) {
    if (scrollHandler) {
      document.scrollingElement.removeEventListener('scroll', scrollHandler);
      scrollHandler = null;
    }
    mode = m;
    if (!rec) return renderMissing();
    if (m === 'reader' && cur) renderReader();
    else if (m === 'search') renderSearch();
    else if (m === 'bookmarks') renderBookmarks();
    else {
      mode = 'index';
      renderIndex();
    }
  }

  store.subscribe((s) => {
    const m = root.querySelector('.mushaf');
    if (m) m.style.fontSize = `${s.quranFontSize}px`;
  });
  onDataChange(() => ensure());
  ensure();

  return {
    onShow() {
      if (mode === 'index' && rec) renderIndex(); // refresh "continue reading" / bookmark count
    },
    onHide() {
      /* nothing running in background */
    },
  };
}
