// Location handling: GPS (only on user action), manual city, custom coordinates.
import { store } from './store.js';
import { deviceTimeZone } from './prayer-service.js';

const GEO_ERRORS = {
  1: 'تم رفض إذن الموقع. يمكنك اختيار المدينة يدويًا من الإعدادات، أو السماح بالموقع من إعدادات المتصفح.',
  2: 'تعذّر تحديد الموقع. تأكد من تشغيل خدمة الموقع (GPS) في جهازك.',
  3: 'انتهت مهلة تحديد الموقع. حاول مرة أخرى في مكان مفتوح.',
};

export function geolocationSupported() {
  return typeof navigator !== 'undefined' && 'geolocation' in navigator;
}

/** Resolves {ok:true} after saving the location, or {ok:false, message}. Never throws. */
export function useCurrentLocation() {
  return new Promise((resolve) => {
    if (!geolocationSupported()) return resolve({ ok: false, message: 'المتصفح لا يدعم تحديد الموقع. اختر المدينة يدويًا.' });
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        store.update({
          location: { name: `موقعك الحالي (${latitude.toFixed(2)}، ${longitude.toFixed(2)})`, lat: latitude, lng: longitude, tz: deviceTimeZone(), source: 'gps' },
        });
        resolve({ ok: true });
      },
      (err) => resolve({ ok: false, denied: err.code === 1, message: GEO_ERRORS[err.code] || 'تعذّر تحديد الموقع.' }),
      { enableHighAccuracy: false, timeout: 15000, maximumAge: 10 * 60 * 1000 },
    );
  });
}

export function setCity(city) {
  store.update({ location: { name: city.name, lat: city.lat, lng: city.lng, tz: city.tz, source: 'city' } });
}

export function setCustom({ name, lat, lng }) {
  const la = Number(lat);
  const ln = Number(lng);
  if (!Number.isFinite(la) || !Number.isFinite(ln) || Math.abs(la) > 90 || Math.abs(ln) > 180) return { ok: false, message: 'إحداثيات غير صحيحة (خط العرض من -90 إلى 90، وخط الطول من -180 إلى 180).' };
  store.update({ location: { name: name?.trim() || `موقع مخصص (${la.toFixed(2)}، ${ln.toFixed(2)})`, lat: la, lng: ln, tz: deviceTimeZone(), source: 'custom' } });
  return { ok: true };
}

/** Optional: asks OpenStreetMap Nominatim for a place name. Sends coordinates, so the UI asks consent first. */
export async function reverseGeocode() {
  const { lat, lng } = store.get().location;
  try {
    const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=10&accept-language=ar&lat=${lat}&lon=${lng}`;
    const res = await fetch(url, { credentials: 'omit', referrerPolicy: 'no-referrer' });
    if (!res.ok) throw new Error(String(res.status));
    const j = await res.json();
    const a = j.address || {};
    const name = [a.city || a.town || a.village || a.county, a.state || a.country].filter(Boolean).join('، ');
    if (!name) return { ok: false, message: 'لم يتم العثور على اسم للمدينة.' };
    store.update({ location: { ...store.get().location, name } });
    return { ok: true, name };
  } catch {
    return { ok: false, message: 'تعذّر الحصول على اسم المدينة (تحقق من الاتصال بالإنترنت).' };
  }
}

export function locationStatusText(loc) {
  switch (loc.source) {
    case 'gps': return 'الموقع الحالي (GPS)';
    case 'city': return 'مدينة مختارة يدويًا';
    case 'custom': return 'إحداثيات مدخلة يدويًا';
    default: return 'الموقع الافتراضي — لم تحدد موقعك بعد';
  }
}
