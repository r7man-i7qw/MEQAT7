// Service worker: caches the app shell for offline use. Quran/Adhkar data live in IndexedDB, not here.
const VERSION = 'meqat-shell-v1';
const SHELL = [
  './', 'index.html', 'manifest.webmanifest', 'css/style.css', 'icons/icon.svg', 'icons/icon-192.png', 'icons/icon-512.png', 'sounds/manifest.json',
  'js/app.js', 'js/adhan.js', 'js/adhan-core.js', 'js/adhkar-source.js', 'js/config.js', 'js/counter.js', 'js/data-actions.js', 'js/data.js', 'js/dom.js',
  'js/idb.js', 'js/location.js', 'js/prayer-service.js', 'js/prayer.js', 'js/qibla.js', 'js/quran-sources.js', 'js/quran-validate.js', 'js/store.js',
  'js/views/home.js', 'js/views/qibla.js', 'js/views/quran.js', 'js/views/adhkar.js', 'js/views/settings.js',
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== VERSION && k.startsWith('meqat-')).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  const sameOrigin = url.origin === location.origin;
  const isFont = url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com';
  if (!sameOrigin && !isFont) return; // data APIs are never intercepted or cached here
  e.respondWith(
    caches.match(req).then((hit) => {
      const net = fetch(req).then((res) => {
        if (res && (res.ok || res.type === 'opaque')) {
          const copy = res.clone();
          caches.open(VERSION).then((c) => c.put(req, copy));
        }
        return res;
      });
      if (hit) {
        net.catch(() => {});
        return hit; // stale-while-revalidate
      }
      return net.catch(() => (req.mode === 'navigate' ? caches.match('index.html') : Response.error()));
    }),
  );
});

self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  e.waitUntil(self.clients.matchAll({ type: 'window' }).then((list) => (list.length ? list[0].focus() : self.clients.openWindow('./'))));
});
