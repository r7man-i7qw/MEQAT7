# End-to-end smoke test (Playwright). Run: python3 tests/e2e/make_fixtures.py && python3 tests/e2e/smoke.py
# Fixtures are STRUCTURE-ONLY placeholders (no real Quran/Adhkar text) used to exercise the UI.
import json, re, subprocess, time, sys, os
from playwright.sync_api import sync_playwright

BASE = 'http://127.0.0.1:8765/'
HERE = os.path.dirname(os.path.abspath(__file__))
results = []
def check(name, cond, extra=''):
    results.append((name, bool(cond)))
    print(('PASS' if cond else 'FAIL'), name, extra)

server = subprocess.Popen(['python3', '-m', 'http.server', '8765', '--bind', '127.0.0.1'], cwd=os.path.join(HERE,'..','..'), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1)
try:
    with sync_playwright() as p:
        b = p.chromium.launch(args=['--no-sandbox'])
        ctx = b.new_context(locale='ar-EG', timezone_id='Africa/Cairo', permissions=['notifications'], viewport={'width': 390, 'height': 800}, service_workers='allow')
        page = ctx.new_page()
        errors = []
        page.on('pageerror', lambda e: errors.append(f'pageerror: {e}'))
        page.on('console', lambda m: errors.append(f'console: {m.text}') if m.type == 'error' and 'fonts.g' not in m.text and 'ERR_' not in m.text and 'Failed to load resource' not in m.text else None)

        page.goto(BASE)
        page.wait_for_selector('.prayer-row', timeout=8000)
        check('home renders 6 rows (5 prayers + sunrise)', page.locator('#view-home .prayer-row').count() == 6)
        check('default city is Bir al-Abd', 'بئر العبد' in page.inner_text('#view-home .city'))
        check('default location banner shown', page.locator('#view-home .banner').first.is_visible())
        check('sunrise row labelled not-a-prayer', 'ليست صلاة' in page.inner_text('#view-home .prayer-row.sunrise'))
        c1 = page.inner_text('#view-home .countdown'); time.sleep(2.2); c2 = page.inner_text('#view-home .countdown')
        check('countdown ticks live', c1 != c2, f'{c1} -> {c2}')
        check('next prayer row highlighted', page.locator('#view-home .prayer-row.next').count() == 1)
        check('hijri date shown', len(page.inner_text('#view-home .date').strip()) > 5, page.inner_text('#view-home .date'))
        fajr_before = page.locator('#view-home .prayer-row').nth(0).inner_text()

        # tabs
        for tab in ['qibla', 'quran', 'adhkar', 'settings', 'home']:
            page.click(f'#tabs a[data-tab="{tab}"]')
            try:
                page.wait_for_selector(f'#view-{tab}.active', timeout=2000); ok = True
            except Exception: ok = False
            check(f'tab {tab} becomes active', ok and page.locator('.view.active').count() == 1)

        # qibla static
        page.click('#tabs a[data-tab="qibla"]')
        deg = page.inner_text('#view-qibla .big-deg')
        check('qibla shows degrees', '°' in deg, deg)
        page.click('#view-qibla .btn')
        page.wait_for_timeout(3600)
        msg = page.inner_text('#view-qibla .banner') if page.locator('#view-qibla .banner:not([hidden])').count() else ''
        check('no-sensor state explained (headless has no compass)', 'مستشعر' in msg or 'بوصلة' in msg or 'قراءات' in msg, msg[:80])

        # settings: method change updates home
        page.click('#tabs a[data-tab="settings"]')
        page.wait_for_selector('#view-settings select')
        page.locator('#view-settings select[aria-label="طريقة الحساب"]').select_option('mwl')
        page.click('#tabs a[data-tab="home"]')
        fajr_after = page.locator('#view-home .prayer-row').nth(0).inner_text()
        check('changing calculation method changes Fajr', fajr_before != fajr_after, f'{fajr_before!r} -> {fajr_after!r}')
        page.click('#tabs a[data-tab="settings"]')
        page.locator('#view-settings select[aria-label="طريقة الحساب"]').select_option('egypt')

        # city change
        page.locator('#view-settings select[aria-label="المدينة"]').select_option('alexandria')
        page.click('#tabs a[data-tab="home"]')
        check('city change reflected on home', 'الإسكندرية' in page.inner_text('#view-home .city'))
        check('default banner disappears after manual city', page.locator('#view-home .banner:not([hidden])').count() == 0)

        # time format
        page.click('#tabs a[data-tab="settings"]')
        page.locator('#view-settings select[aria-label="تنسيق الوقت"]').select_option('24')
        page.click('#tabs a[data-tab="home"]')
        check('24h format has no AM/PM marker', not re.search(r'[صم]\s*$', page.locator('#view-home .ptime').first.inner_text().strip()), page.locator('#view-home .ptime').first.inner_text())
        page.click('#tabs a[data-tab="settings"]')
        page.locator('#view-settings select[aria-label="تنسيق الوقت"]').select_option('12')

        # dark theme
        page.locator('#view-settings select[aria-label="السمة"]').select_option('dark')
        bg = page.evaluate('getComputedStyle(document.body).backgroundColor')
        check('dark theme applies', bg == 'rgb(18, 20, 16)', bg)
        page.locator('#view-settings select[aria-label="السمة"]').select_option('light')
        bg = page.evaluate('getComputedStyle(document.body).backgroundColor')
        check('light theme applies', bg == 'rgb(250, 249, 246)', bg)

        # About: whatsapp hidden while no number configured; instagram present
        about = page.inner_text('#view-settings')
        check('about shows developer and instagram', 'عبدالرحمن أحمد' in about and 'r7man.i' in about)
        check('no WhatsApp dead button when number is empty', 'WhatsApp' not in about.replace('Instagram', '') or page.locator('#view-settings a[href*="wa.me"]').count() == 0)

        # Quran: missing state, download failure state (sandbox blocks network), import synthetic
        page.click('#tabs a[data-tab="quran"]')
        check('quran shows "not downloaded" state', 'غير متوفرة' in page.inner_text('#view-quran'))
        page.click('#view-quran .btn')
        page.wait_for_function("document.querySelector('#view-quran .banner.warn')", timeout=90000)
        check('quran download failure shows Arabic error, not blank/fake data', 'تعذّر' in page.inner_text('#view-quran .banner.warn'))
        check('retry button still available', page.locator('#view-quran .btn:not([disabled])').count() >= 1)
        page.click('#tabs a[data-tab="settings"]')
        with page.expect_file_chooser() as fc:
            page.locator('#view-settings .srow:has-text("القرآن الكريم") ~ .row-center .btn.ghost').first.click()
        fc.value.set_files(os.path.join(HERE, 'synth_quran.json'))
        page.wait_for_function("document.querySelector('#view-settings .data-msg')?.innerText.includes('تم استيراد')", timeout=15000)
        check('import of structurally valid file accepted', True)

        # bad import rejected
        bad = os.path.join(HERE, 'bad.json')
        d = json.load(open(os.path.join(HERE, 'synth_quran.json'))); d['data']['surahs'][1]['ayahs'].pop(); json.dump(d, open(bad, 'w'), ensure_ascii=False)
        with page.expect_file_chooser() as fc:
            page.locator('#view-settings .srow:has-text("القرآن الكريم") ~ .row-center .btn.ghost').first.click()
        fc.value.set_files(bad)
        page.wait_for_function("document.querySelector('#view-settings .data-msg.warn')?.innerText.includes('فحص')", timeout=15000)
        check('import with wrong ayah count rejected by integrity check', True)

        page.click('#tabs a[data-tab="quran"]')
        page.wait_for_selector('.surah-item', timeout=8000)
        check('index lists 114 surahs', page.locator('#view-quran .surah-item').count() == 114)
        page.fill('#view-quran input[type="search"]', 'اختبار 2')
        page.wait_for_timeout(300)
        check('index filter works', 0 < page.locator('#view-quran .surah-item').count() < 114)
        page.fill('#view-quran input[type="search"]', '')
        page.wait_for_timeout(300)
        page.locator('#view-quran .surah-item').nth(1).click()
        page.wait_for_selector('.ayah')
        check('reader shows all 286 ayat of surah 2', page.locator('#view-quran .ayah').count() == 286)
        check('reader shows surah name and page labels', page.locator('#view-quran .surah-banner').count() == 1 and page.locator('#view-quran .page-divider').count() > 0)
        page.locator('#view-quran .ayah[data-a="5"]').click()
        page.locator('#view-quran .ayah[data-a="40"]').click()
        check('bookmarks toggle on ayah tap', page.locator('#view-quran .ayah.bm').count() == 2)
        page.fill('#view-quran input[type="number"]', '200')
        page.locator('#view-quran .toolbar .btn').first.click()
        page.wait_for_timeout(900)
        check('goto-ayah scrolls', page.evaluate('window.scrollY') > 500)
        fs0 = page.evaluate("parseFloat(getComputedStyle(document.querySelector('.mushaf')).fontSize)")
        page.click('#view-quran .font-ctl button[aria-label="تكبير الخط"]')
        fs1 = page.evaluate("parseFloat(getComputedStyle(document.querySelector('.mushaf')).fontSize)")
        check('font size increases', fs1 > fs0, f'{fs0}->{fs1}')
        page.wait_for_timeout(700)
        saved = page.evaluate("JSON.parse(localStorage.getItem('meqat.kv.lastRead'))")
        check('last read position saved', saved and saved['s'] == 2 and saved['a'] > 100, str(saved))

        # search + bookmarks screens
        page.click('#view-quran .reader-bar .btn')
        page.locator('#view-quran .toolbar .btn', has_text='بحث').click()
        page.fill('#view-quran input[type="search"]', 'تجريبي 3 7')
        page.wait_for_timeout(600)
        check('text search returns results', page.locator('#view-quran .result').count() > 0)
        page.click('#view-quran .reader-bar .btn')
        page.locator('#view-quran .toolbar .btn', has_text='العلامات').click()
        check('bookmark list shows 2 entries', page.locator('#view-quran .bm-row').count() == 2)

        # persistence after reload
        page.reload(); page.wait_for_selector('#tabs a.on')
        page.click('#tabs a[data-tab="quran"]')
        page.wait_for_selector('.resume')
        check('after reload quran data still offline-available + resume card', page.locator('#view-quran .resume').count() == 1 and page.locator('#view-quran .surah-item').count() == 114)
        page.click('#tabs a[data-tab="home"]'); page.wait_for_selector('#view-home .prayer-row')
        check('city setting persisted after reload', 'الإسكندرية' in page.inner_text('#view-home .city'))
        page.click('#tabs a[data-tab="quran"]')

        # Adhkar
        page.click('#tabs a[data-tab="adhkar"]')
        check('adhkar not-downloaded state', 'غير متوفرة' in page.inner_text('#view-adhkar'))
        page.click('#tabs a[data-tab="settings"]')
        with page.expect_file_chooser() as fc:
            page.locator('#view-settings .srow:has-text("الأذكار") ~ .row-center .btn.ghost').first.click()
        fc.value.set_files(os.path.join(HERE, 'synth_adhkar.json'))
        page.wait_for_function("document.querySelector('#view-settings .data-msg')?.innerText.includes('تم استيراد')", timeout=15000)
        page.click('#tabs a[data-tab="adhkar"]')
        page.wait_for_selector('.cat-card')
        titles = page.locator('#view-adhkar .cat-title').all_inner_texts()
        check('adhkar sections present (source titles never invented)', 'أذكار الصباح والمساء' in titles and 'أذكار النوم' in titles and 'أذكار الاستيقاظ' in titles and 'أذكار بعد الصلاة' in titles and 'أذكار متنوعة' in titles, str(titles))
        page.locator('#view-adhkar .cat-card').first.click()
        page.wait_for_selector('.counter')
        page.click('.counter'); page.click('.counter')
        check('counter increments on tap', page.inner_text('.cnum').strip() in ('٢', '2'), page.inner_text('.cnum'))
        page.reload(); page.wait_for_selector('#tabs a.on')
        page.click('#tabs a[data-tab="adhkar"]'); page.wait_for_selector('.cat-card')
        page.locator('#view-adhkar .cat-card').first.click(); page.wait_for_selector('.counter')
        check('adhkar progress persists after reload and resumes at same dhikr', page.inner_text('.cnum').strip() in ('٢', '2'), page.inner_text('.cnum'))
        page.click('.counter')
        page.wait_for_timeout(900)
        check('completing a dhikr advances to the next', 'الذكر ٢' in page.inner_text('#view-adhkar') or 'الذكر 2' in page.inner_text('#view-adhkar'))
        page.locator('#view-adhkar .btn', has_text='إعادة العدّاد').click()
        check('reset counter works', page.inner_text('.cnum').strip() in ('٠', '0'))

        # Alerts scheduling + firing with a fake clock
        page.click('#tabs a[data-tab="settings"]')
        page.locator('#view-settings details.prayer-set summary', has_text='العشاء').click()
        page.locator('#view-settings details.prayer-set[open] input.switch').first.click()
        page.wait_for_timeout(600)
        check('prayer panel stays open after toggling alert (no UI collapse)', page.locator('#view-settings details.prayer-set[open]').count() == 1)
        page.wait_for_function("document.querySelector('#view-settings')?.innerText.includes('التنبيه القادم')", timeout=8000)
        st = page.evaluate("[...document.querySelectorAll('#view-settings .banner')].map(b=>b.innerText).find(t=>t.includes('التنبيه القادم'))")
        check('schedule status reports a really armed alert', st and 'العشاء' in st, st)

        b.close()

        # Fire test in a fresh context with controlled clock
        b2 = p.chromium.launch(args=['--no-sandbox'])
        c2 = b2.new_context(locale='ar-EG', timezone_id='Africa/Cairo', permissions=['notifications'], service_workers='block')
        pg = c2.new_page()
        pg.clock.install(time='2026-11-17T12:00:00+02:00')
        pg.add_init_script("localStorage.setItem('meqat.settings.v1', JSON.stringify({alerts:{dhuhr:{alert:true,adhan:false,sound:'chime',mode:'short',pre:10},maghrib:{alert:true}}}))")
        pg.goto(BASE)
        pg.wait_for_selector('.prayer-row')
        pg.wait_for_timeout(300)
        pg.clock.run_for(60 * 60 * 1000 * 6)  # 6 hours: past dhuhr and maghrib
        pg.wait_for_timeout(500)
        toasts = pg.evaluate("window.__toasts || []")
        pg.clock.run_for(1000)
        txt = pg.inner_text('#toast')
        check('alert fires (toast shows a prayer announcement)', 'صلاة' in txt, txt)
        check('app still alive after timers fired', pg.locator('.prayer-row').count() >= 6)
        # next prayer moves on: after 6h from noon (18:00 Cairo) next must be Isha or later
        nxt = pg.inner_text('#view-home .next-name')
        check('home advanced to following prayer automatically', 'العشاء' in nxt or 'الفجر' in nxt, nxt)
        b2.close()

        # Offline shell via service worker
        b3 = p.chromium.launch(args=['--no-sandbox'])
        c3 = b3.new_context(locale='ar-EG', timezone_id='Africa/Cairo', service_workers='allow')
        pg3 = c3.new_page()
        pg3.goto(BASE); pg3.wait_for_selector('.prayer-row')
        pg3.evaluate("navigator.serviceWorker.ready.then(()=>1)")
        pg3.wait_for_timeout(1500)
        c3.set_offline(True)
        pg3.reload(); pg3.wait_for_selector('.prayer-row', timeout=8000)
        check('app loads and computes prayer times fully offline', pg3.locator('.prayer-row').count() == 6)
        pg3.click('#tabs a[data-tab="quran"]'); pg3.click('#view-quran .btn')
        pg3.wait_for_function("document.querySelector('#view-quran .banner')?.innerText.includes('إنترنت')", timeout=8000)
        check('offline download attempt explains offline state', True)
        b3.close()

        # geolocation denied/granted
        b4 = p.chromium.launch(args=['--no-sandbox'])
        c4 = b4.new_context(locale='ar-EG', timezone_id='Africa/Cairo', permissions=[], service_workers='block')
        pg4 = c4.new_page(); pg4.goto(BASE); pg4.wait_for_selector('.prayer-row')
        pg4.click('#tabs a[data-tab="settings"]'); pg4.wait_for_selector('#view-settings .btn')
        pg4.locator('#view-settings .btn', has_text='استخدام موقعي الحالي').click()
        pg4.wait_for_timeout(1200)
        denied_msg = pg4.inner_text('#view-settings .banner.warn') if pg4.locator('#view-settings .banner.warn').count() else ''
        check('denied location permission handled; app keeps working with manual/default location', ('رفض' in denied_msg or 'تعذّر' in denied_msg) and 'بئر العبد' in pg4.inner_text('#view-settings'), denied_msg[:70])
        c4.grant_permissions(['geolocation']); c4.set_geolocation({'latitude': 30.0444, 'longitude': 31.2357})
        pg4.locator('#view-settings .btn', has_text='استخدام موقعي الحالي').click()
        pg4.wait_for_function("document.querySelector('#view-settings')?.innerText.includes('GPS')", timeout=8000)
        check('granted location switches to GPS source', True)
        b4.close()

        print('---- JS errors:', len(errors))
        for e in errors[:10]: print(e)
        check('no uncaught JS errors / console errors', len(errors) == 0)
finally:
    server.terminate()

fails = [n for n, ok in results if not ok]
print(f'\n{len(results)-len(fails)}/{len(results)} passed')
if fails: print('FAILED:', fails); sys.exit(1)
