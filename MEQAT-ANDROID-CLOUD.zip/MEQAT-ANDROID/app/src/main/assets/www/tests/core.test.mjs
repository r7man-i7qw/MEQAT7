import test from 'node:test';
import assert from 'node:assert/strict';
import { computeTimes, findNextPrayer, formatCountdown, METHODS, PRAYERS } from '../js/prayer.js';
import { qiblaBearing, distanceKm, angleDiff, smoothHeading, headingJitter, toTrueHeading } from '../js/qibla.js';
import { AYAH_COUNTS, TOTAL_AYAT, validateQuran, normalizeArabic, splitBasmala } from '../js/quran-validate.js';
import { parseAdhkar, validateAdhkar, groupAdhkar } from '../js/adhkar-source.js';
import * as C from '../js/counter.js';
import { createStore, DEFAULTS, deepMerge } from '../js/store.js';
import { buildEvents, isStale } from '../js/adhan-core.js';
import { parseAlQuranCloud, parseAnyQuranJSON } from '../js/quran-sources.js';

const memStorage = () => {
  const m = new Map();
  return {
    getItem: (k) => (m.has(k) ? m.get(k) : null),
    setItem: (k, v) => m.set(k, String(v)),
    removeItem: (k) => m.delete(k),
    key: (i) => [...m.keys()][i] ?? null,
    get length() { return m.size; },
  };
};

const CAIRO = { y: 2026, m: 11, d: 17, lat: 30.0444, lng: 31.2357, tz: 2 };
const localHour = (date, { y, m, d, tz }) => (date.getTime() - (Date.UTC(y, m - 1, d) - tz * 3600e3)) / 3600e3;

// ---------- prayer times ----------
test('prayer: Cairo times fall in plausible windows for mid-November', () => {
  const t = computeTimes({ ...CAIRO, method: 'egypt' });
  const h = (k) => localHour(t[k], CAIRO);
  assert.ok(h('fajr') > 4.5 && h('fajr') < 5.3, `fajr ${h('fajr')}`);
  assert.ok(h('sunrise') > 6.0 && h('sunrise') < 6.7, `sunrise ${h('sunrise')}`);
  assert.ok(h('dhuhr') > 11.6 && h('dhuhr') < 12.1, `dhuhr ${h('dhuhr')}`);
  assert.ok(h('asr') > 14.5 && h('asr') < 15.2, `asr ${h('asr')}`);
  assert.ok(h('maghrib') > 16.9 && h('maghrib') < 17.6, `maghrib ${h('maghrib')}`);
  assert.ok(h('isha') > 18.1 && h('isha') < 19.2, `isha ${h('isha')}`);
});

test('prayer: chronological order and sunrise is separate from the five prayers', () => {
  const t = computeTimes({ ...CAIRO });
  const order = ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'].map((k) => t[k].getTime());
  assert.deepEqual([...order].sort((a, b) => a - b), order);
  assert.deepEqual(PRAYERS, ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha']);
});

test('prayer: sunrise and sunset are symmetric around solar noon (independent consistency check)', () => {
  for (const loc of [CAIRO, { y: 2026, m: 6, d: 21, lat: 21.4225, lng: 39.8262, tz: 3 }, { y: 2026, m: 3, d: 20, lat: 31.02, lng: 33, tz: 2 }]) {
    const t = computeTimes({ ...loc });
    const mid = (t.sunrise.getTime() + t.maghrib.getTime()) / 2;
    assert.ok(Math.abs(mid - t.dhuhr.getTime()) <= 4 * 60000, 'noon should be midpoint of sunrise/sunset within 4 min');
  }
});

test('prayer: methods are not identical and differ in the expected direction', () => {
  const egypt = computeTimes({ ...CAIRO, method: 'egypt' });
  const mwl = computeTimes({ ...CAIRO, method: 'mwl' });
  const isna = computeTimes({ ...CAIRO, method: 'isna' });
  assert.ok(egypt.fajr < mwl.fajr, 'larger twilight angle => earlier fajr');
  assert.ok(mwl.fajr < isna.fajr);
  assert.ok(egypt.isha > mwl.isha, 'Egypt isha angle 17.5 > MWL 17 => later isha');
  assert.equal(egypt.dhuhr.getTime(), mwl.dhuhr.getTime());
  assert.equal(Object.keys(METHODS).length, 5);
});

test('prayer: Hanafi asr is later than standard asr', () => {
  const s = computeTimes({ ...CAIRO, asr: 'standard' });
  const h = computeTimes({ ...CAIRO, asr: 'hanafi' });
  assert.ok(h.asr > s.asr);
  assert.equal(h.dhuhr.getTime(), s.dhuhr.getTime());
});

test('prayer: Umm al-Qura isha is 90 min after maghrib (120 in Ramadan)', () => {
  const mecca = { y: 2026, m: 11, d: 17, lat: 21.4225, lng: 39.8262, tz: 3 };
  const a = computeTimes({ ...mecca, method: 'makkah' });
  assert.equal((a.isha - a.maghrib) / 60000, 90);
  const r = computeTimes({ ...mecca, method: 'makkah', ramadan: true });
  assert.equal((r.isha - r.maghrib) / 60000, 120);
});

test('prayer: manual minute adjustments apply to the chosen prayer only', () => {
  const base = computeTimes({ ...CAIRO });
  const adj = computeTimes({ ...CAIRO, adjust: { fajr: 3, isha: -2 } });
  assert.equal((adj.fajr - base.fajr) / 60000, 3);
  assert.equal((adj.isha - base.isha) / 60000, -2);
  assert.equal(adj.dhuhr.getTime(), base.dhuhr.getTime());
});

test('prayer: changing city changes times; time zone offset shifts instants correctly', () => {
  const cairo = computeTimes({ ...CAIRO });
  const alex = computeTimes({ ...CAIRO, lat: 31.2001, lng: 29.9187 });
  assert.ok(alex.dhuhr > cairo.dhuhr, 'Alexandria is west of Cairo => later solar noon');
  const plus3 = computeTimes({ ...CAIRO, tz: 3 });
  assert.equal(plus3.dhuhr.getTime(), cairo.dhuhr.getTime() - 0 , 'absolute instant of noon must not depend on the offset label');
});

test('prayer: invalid input and polar day throw instead of returning garbage', () => {
  assert.throws(() => computeTimes({ ...CAIRO, method: 'nope' }));
  assert.throws(() => computeTimes({ ...CAIRO, lat: NaN }));
  assert.throws(() => computeTimes({ y: 2026, m: 6, d: 21, lat: 78, lng: 15, tz: 2 }), /NO_SOLUTION/);
});

test('prayer: next-prayer transitions', () => {
  const t = computeTimes({ ...CAIRO });
  const at = (ms) => new Date(ms);
  assert.equal(findNextPrayer(t, at(t.fajr.getTime() - 1000)).key, 'fajr');
  assert.equal(findNextPrayer(t, at(t.fajr.getTime())).key, 'dhuhr', 'at the exact prayer time it moves on');
  assert.equal(findNextPrayer(t, at(t.sunrise.getTime())).key, 'dhuhr', 'sunrise is not a prayer');
  assert.equal(findNextPrayer(t, at(t.asr.getTime() + 1)).key, 'maghrib');
  assert.equal(findNextPrayer(t, at(t.isha.getTime() + 1)), null, 'after isha the caller must use tomorrow');
});

test('prayer: countdown formatting', () => {
  assert.equal(formatCountdown(0), '00:00:00');
  assert.equal(formatCountdown(3661000), '01:01:01');
  assert.equal(formatCountdown(-5000), '00:00:00');
  assert.equal(formatCountdown(59999), '00:00:59');
});

// ---------- qibla ----------
test('qibla: known city bearings (great-circle, from true north)', () => {
  const cases = [
    ['Cairo', 30.0444, 31.2357, 136.2, 1.0],
    ['London', 51.5074, -0.1278, 119.0, 0.7],
    ['New York', 40.7128, -74.006, 58.5, 0.7],
    ['Jakarta', -6.2088, 106.8456, 295.1, 1.5],
    ['Sydney', -33.8688, 151.2093, 277.5, 1.5],
  ];
  for (const [name, lat, lng, expected, tol] of cases) {
    const b = qiblaBearing(lat, lng);
    assert.ok(Math.abs(angleDiff(b, expected)) <= tol, `${name}: got ${b.toFixed(2)}, expected ~${expected}`);
  }
});

test('qibla: distance and heading helpers', () => {
  const d = distanceKm(30.0444, 31.2357);
  assert.ok(d > 1200 && d < 1350, `Cairo-Mecca ${d}`);
  assert.equal(angleDiff(10, 350), 20);
  assert.equal(angleDiff(350, 10), -20);
  assert.ok(Math.abs(smoothHeading(350, 10, 0.5) - 0) < 1e-9 || Math.abs(smoothHeading(350, 10, 0.5) - 360) < 1e-9);
  assert.equal(smoothHeading(null, 123), 123);
  assert.ok(headingJitter([10, 11, 9, 10, 10, 11]) < 2);
  assert.ok(headingJitter([0, 90, 180, 270, 45, 200]) > 40);
  assert.equal(toTrueHeading(355, 10), 5);
});

// ---------- quran validation (synthetic structure only) ----------
const syntheticQuran = () => ({
  surahs: AYAH_COUNTS.map((c, i) => ({ n: i + 1, name: `سورة ${i + 1}`, type: null, ayahs: Array.from({ length: c }, () => 'ا'), pages: null })),
});

test('quran: canonical count table is 114 surahs / 6236 ayat', () => {
  assert.equal(AYAH_COUNTS.length, 114);
  assert.equal(AYAH_COUNTS.reduce((a, b) => a + b, 0), TOTAL_AYAT);
  assert.equal(TOTAL_AYAT, 6236);
});

test('quran: validator accepts a structurally complete dataset and rejects broken ones', () => {
  assert.equal(validateQuran(syntheticQuran()).ok, true);
  const missing = syntheticQuran();
  missing.surahs.pop();
  assert.equal(validateQuran(missing).ok, false);
  const short = syntheticQuran();
  short.surahs[1].ayahs.pop();
  const r = validateQuran(short);
  assert.equal(r.ok, false);
  assert.match(r.errors.join(' '), /286/);
  const empty = syntheticQuran();
  empty.surahs[0].ayahs[0] = '';
  assert.equal(validateQuran(empty).ok, false);
  const latin = syntheticQuran();
  latin.surahs[5].ayahs[3] = 'hello';
  assert.equal(validateQuran(latin).ok, false);
  const order = syntheticQuran();
  [order.surahs[0], order.surahs[1]] = [order.surahs[1], order.surahs[0]];
  assert.equal(validateQuran(order).ok, false);
  assert.equal(validateQuran(null).ok, false);
});

test('quran: parsers map the AlQuran-Cloud shape and reject malformed shapes', () => {
  const json = { data: { surahs: [{ number: 1, name: 'x', revelationType: 'Meccan', ayahs: [{ text: 'ا', numberInSurah: 1, page: 1 }, { text: 'ب', numberInSurah: 2, page: 1 }] }] } };
  const [s] = parseAlQuranCloud(json);
  assert.deepEqual({ n: s.n, type: s.type, pages: s.pages, len: s.ayahs.length }, { n: 1, type: 'makki', pages: [1, 1], len: 2 });
  assert.throws(() => parseAlQuranCloud({ data: { surahs: [{ number: 1, name: 'x', ayahs: [{ text: 'ا', numberInSurah: 2 }] }] } }));
  assert.throws(() => parseAnyQuranJSON({ foo: 1 }));
  assert.equal(parseAnyQuranJSON(json).length, 1);
});

test('quran: search normalization and basmala splitting never alter text', () => {
  assert.equal(normalizeArabic('ٱلرَّحْمَٰنِ'), 'الرحمن');
  assert.equal(normalizeArabic('أَحَدٌ'), 'احد');
  const plain = 'بسم الله الرحمن الرحيم الم';
  const split = splitBasmala(plain, 2, 1);
  assert.equal(split.basmala, 'بسم الله الرحمن الرحيم');
  assert.equal(`${split.basmala} ${split.text}`, plain, 'concatenation must reproduce the original');
  assert.equal(splitBasmala(plain, 1, 1).basmala, null, 'in Al-Fatiha the basmala is ayah 1');
  assert.equal(splitBasmala(plain, 9, 1).basmala, null);
  assert.equal(splitBasmala(plain, 2, 2).basmala, null);
  assert.equal(splitBasmala('ا ب ج د ه', 2, 1).basmala, null);
});

// ---------- adhkar ----------
test('adhkar: parser handles shapes, drops empty items, keeps unknown counts as null', () => {
  const cats = parseAdhkar([
    { category: 'أذكار الصباح والمساء', array: [{ text: 'نص', count: 3 }, { text: '  ', count: 1 }, { text: 'نص ٢', count: 'x' }] },
    { category: '', array: [{ text: 'a' }] },
    { title: 'تصنيف', items: [{ text: 'نص', count: '7' }] },
  ]);
  assert.equal(cats.length, 2);
  assert.deepEqual(cats[0].items.map((i) => i.count), [3, null]);
  assert.equal(cats[1].items[0].count, 7);
  assert.throws(() => parseAdhkar({ nope: 1 }));
  assert.equal(parseAdhkar({ categories: [{ category: 'ت', array: [{ text: 'ن', count: 1 }] }] }).length, 1);
});

test('adhkar: validator and grouping into the requested sections', () => {
  const mk = (title) => ({ id: title, title, items: [{ text: 'نص', count: 1 }] });
  const titles = ['أذكار الصباح والمساء', 'أذكار النوم', 'أذكار الاستيقاظ من النوم', 'أذكار بعد السلام من الصلاة المفروضة', 'دعاء دخول المسجد', 'دعاء الكرب'];
  const g = groupAdhkar(titles.map(mk));
  assert.equal(g.morningEvening.length, 1);
  assert.equal(g.sleep.length, 1);
  assert.equal(g.wake.length, 1, 'wake-up must not be mistaken for sleep');
  assert.equal(g.afterPrayer.length, 1);
  assert.equal(g.misc.length, 2);
  assert.equal(validateAdhkar(titles.map(mk)).ok, true);
  assert.equal(validateAdhkar([mk('a')]).ok, false);
  const bad = titles.map(mk);
  bad[0].items[0].text = 'latin only';
  assert.equal(validateAdhkar(bad).ok, false);
});

test('adhkar counter: taps, target cap, reset, category progress, daily reset', () => {
  let p = C.freshProgress('2026-11-17');
  const k = C.itemKey('c1', 0);
  p = C.tap(p, k, 3);
  p = C.tap(p, k, 3);
  assert.equal(C.getCount(p, k), 2);
  assert.equal(C.isDone(p, k, 3), false);
  p = C.tap(p, k, 3);
  assert.equal(C.isDone(p, k, 3), true);
  assert.equal(C.getCount(C.tap(p, k, 3), k), 3, 'cannot exceed target');
  const free = C.tap(C.tap(C.freshProgress('d'), 'x', null), 'x', null);
  assert.equal(C.getCount(free, 'x'), 2, 'items without a target count freely');
  assert.equal(C.isDone(free, 'x', null), false);
  const cat = { id: 'c1', items: [{ count: 3 }, { count: 1 }] };
  assert.deepEqual(C.categoryProgress(p, cat), { done: 1, total: 2 });
  assert.equal(C.getCount(C.resetItem(p, k), k), 0);
  assert.equal(C.getCount(C.resetCategory(p, 'c1'), k), 0);
  assert.equal(C.normalizeProgress(p, '2026-11-18').day, '2026-11-18');
  assert.deepEqual(C.normalizeProgress(p, '2026-11-18').counts, {});
  assert.equal(C.normalizeProgress(p, '2026-11-17'), p);
  assert.equal(C.dayKey(new Date(2026, 10, 7)), '2026-11-07');
});

// ---------- settings persistence ----------
test('store: defaults, persistence across instances, merge of new default keys, subscribe, clear', () => {
  const storage = memStorage();
  const a = createStore(storage);
  assert.equal(a.get().method, 'egypt');
  assert.equal(a.get().location.name, 'بئر العبد، شمال سيناء');
  let calls = 0;
  const off = a.subscribe(() => calls++);
  a.update({ method: 'mwl', alerts: { fajr: { alert: true, pre: 10 } }, location: { name: 'القاهرة', lat: 30.0444, lng: 31.2357, tz: 'Africa/Cairo', source: 'city' } });
  assert.equal(calls, 1);
  off();
  a.update({ theme: 'dark' });
  assert.equal(calls, 1);
  const b = createStore(storage);
  assert.equal(b.get().method, 'mwl');
  assert.equal(b.get().theme, 'dark');
  assert.equal(b.get().alerts.fajr.alert, true);
  assert.equal(b.get().alerts.fajr.pre, 10);
  assert.equal(b.get().alerts.dhuhr.alert, false, 'untouched prayer keeps defaults');
  assert.equal(b.get().location.name, 'القاهرة');
  storage.setItem('meqat.settings.v1', JSON.stringify({ method: 'isna' }));
  const c = createStore(storage);
  assert.equal(c.get().method, 'isna');
  assert.equal(c.get().adjust.fajr, 0, 'missing keys filled from defaults');
  storage.setItem('meqat.settings.v1', '{not json');
  assert.equal(createStore(storage).get().method, 'egypt', 'corrupt storage falls back to defaults');
  b.setKV('lastRead', { s: 2, a: 5 });
  assert.deepEqual(createStore(storage).getKV('lastRead'), { s: 2, a: 5 });
  assert.equal(b.getKV('missing', 'fb'), 'fb');
  b.clearAll();
  assert.equal(b.getKV('lastRead', null), null);
  assert.equal(b.get().method, 'egypt');
  assert.deepEqual(deepMerge({ a: { b: 1 } }, { a: { c: 2 } }), { a: { b: 1, c: 2 } });
  assert.deepEqual(DEFAULTS.alerts.fajr.alert, false);
});

test('store: storage that throws does not crash the app', () => {
  const broken = { getItem() { throw new Error('x'); }, setItem() { throw new Error('x'); }, removeItem() {}, key: () => null, length: 0 };
  const s = createStore(broken);
  s.update({ theme: 'dark' });
  assert.equal(s.get().theme, 'dark');
  assert.equal(s.setKV('a', 1), false);
});

// ---------- alert scheduling ----------
test('adhan scheduling: per-prayer enable, pre-alerts, ordering, no duplicates, stale detection', () => {
  const today = computeTimes({ ...CAIRO });
  const tomorrow = computeTimes({ ...CAIRO, d: 18 });
  const alerts = {
    fajr: { alert: true, pre: 15 }, dhuhr: { alert: false, pre: 10 }, asr: { alert: true, pre: 0 },
    maghrib: { alert: true, pre: 5 }, isha: { alert: false, pre: 0 },
  };
  const now = today.fajr.getTime() - 3600e3;
  const ev = buildEvents([today, tomorrow, tomorrow], alerts, now);
  assert.deepEqual(ev.slice(0, 4).map((e) => `${e.prayer}:${e.type}`), ['fajr:pre', 'fajr:at', 'asr:at', 'maghrib:pre']);
  assert.ok(!ev.some((e) => e.prayer === 'dhuhr' || e.prayer === 'isha'), 'disabled prayers never schedule');
  assert.equal(new Set(ev.map((e) => e.id)).size, ev.length, 'no duplicate events even if a day is passed twice');
  assert.deepEqual(ev.map((e) => e.at), [...ev.map((e) => e.at)].sort((a, b) => a - b));
  assert.equal(ev[0].at, today.fajr.getTime() - 15 * 60000);
  const after = buildEvents([today], alerts, today.asr.getTime());
  assert.ok(after.every((e) => e.at > today.asr.getTime()), 'past events are dropped');
  assert.equal(isStale(ev[0], ev[0].at + 200000), true);
  assert.equal(isStale(ev[0], ev[0].at + 1000), false);
});
