# Synthetic, structure-only fixtures used ONLY to exercise the UI. They are not Quran/Adhkar content.
import json, sys
counts=[7,286,200,176,120,165,206,75,129,109,123,111,43,52,99,128,111,110,98,135,112,78,118,64,77,227,93,88,69,60,34,30,73,54,45,83,182,88,75,85,54,53,89,59,37,35,38,29,18,45,60,49,62,55,78,96,29,22,24,13,14,11,11,18,12,12,30,52,52,44,28,28,20,56,40,31,50,40,46,42,29,19,36,25,22,17,19,26,30,20,15,21,11,8,8,19,5,8,8,11,11,8,3,9,5,4,7,3,6,3,5,4,5,6]
assert len(counts)==114 and sum(counts)==6236
surahs=[]
for i,c in enumerate(counts):
    surahs.append({"number":i+1,"name":f"سورة اختبار {i+1}","revelationType":"Meccan" if i%2==0 else "Medinan",
      "ayahs":[{"text":f"نص تجريبي {i+1} {j+1}","numberInSurah":j+1,"page":1+ (i*7+j)//20} for j in range(c)]})
json.dump({"data":{"surahs":surahs}},open('synth_quran.json','w'),ensure_ascii=False)
titles=['أذكار الصباح والمساء','أذكار النوم','أذكار الاستيقاظ من النوم','أذكار بعد السلام من الصلاة المفروضة','دعاء الكرب','دعاء دخول المسجد']
cats=[{"id":i,"category":t,"array":[{"id":1,"text":f"ذكر تجريبي {i} أ","count":3},{"id":2,"text":f"ذكر تجريبي {i} ب","count":1}]} for i,t in enumerate(titles)]
json.dump(cats,open('synth_adhkar.json','w'),ensure_ascii=False)
print('fixtures ok')
